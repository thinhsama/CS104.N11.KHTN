﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;

namespace QLBD
{
    public partial class dangkydoi : Form
    {
        public dangkydoi()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView_DOIBONG_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = dataGridView_DOIBONG.CurrentRow.Index;
            textBox_tendoi.Text = dataGridView_DOIBONG.Rows[i].Cells[0].Value.ToString();
            textBox_sannha.Text = dataGridView_DOIBONG.Rows[i].Cells[1].Value.ToString();
            textBox_succhua.Text = dataGridView_DOIBONG.Rows[i].Cells[2].Value.ToString();
            textBox_diachi.Text = dataGridView_DOIBONG.Rows[i].Cells[3].Value.ToString();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT D.TENDOI as 'Tên đội', S.TENSAN as 'Sân', S.SUCCHUA as 'Sức chứa', S.DIACHI as 'Địa chỉ' \r\nFROM DOIBONG D, SAN S, DOIBONG_MUAGIAI DM\r\nWHERE D.MADOI = DM.MADOI AND DM.MASANNHA = S.MASAN ";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView_DOIBONG.DataSource = table;
        }

        private void dangkydoi_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            loaddata();
            display_comboBox1();
        }
        static int i = 0, j = 0, k = 0;
        private void button_them_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "INSERT INTO DOIBONG VALUES(@madb, @tendb)";
            command.Parameters.AddWithValue("@madb", i);
            command.Parameters.AddWithValue("@tendb", textBox_tendoi.Text);
            command.ExecuteNonQuery();
            command = connection.CreateCommand();
            command.CommandText = "INSERT INTO SAN VALUES(@masan,@tensan, @diachi, @succhua)";
            command.Parameters.AddWithValue("@tensan", textBox_sannha.Text);
            command.Parameters.AddWithValue("@diachi", textBox_diachi.Text);
            command.Parameters.AddWithValue("@succhua", textBox_succhua.Text);
            command.Parameters.AddWithValue("@masan", j);
            command.ExecuteNonQuery();
            command = connection.CreateCommand();
            command.CommandText = "INSERT INTO DOIBONG_MUAGIAI VALUES(@mamua, @madoi, @masannha)";
            command.Parameters.AddWithValue("@mamua", k);
            command.Parameters.AddWithValue("@madoi", i);
            command.Parameters.AddWithValue("@masannha", j);
            command.ExecuteNonQuery();
            i++; j++; k++;
            loaddata();
        }

        public void display_comboBox1()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox1.DisplayMember = "TENMUA";
            comboBox1.DataSource = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataSet1BindingSource4_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void button_sua_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "DELETE FROM DOIBONG WHERE TENDOI = @tendb";
            command.Parameters.AddWithValue("@tendb", textBox_tendoi.Text);
            command.ExecuteNonQuery();
            loaddata();
        }

        private void button_xoa_Click(object sender, EventArgs e)
        {

        }
    }
}
