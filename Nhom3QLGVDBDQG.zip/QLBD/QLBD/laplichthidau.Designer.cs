﻿namespace QLBD
{
    partial class laplichthidau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_laplichthidau = new System.Windows.Forms.Label();
            this.comboBox_chonmuagiai = new System.Windows.Forms.ComboBox();
            this.label_chonmuagiai = new System.Windows.Forms.Label();
            this.label_vongdau = new System.Windows.Forms.Label();
            this.comboBox_vongdau = new System.Windows.Forms.ComboBox();
            this.comboBox_doi1 = new System.Windows.Forms.ComboBox();
            this.label_doi1 = new System.Windows.Forms.Label();
            this.comboBox_doi2 = new System.Windows.Forms.ComboBox();
            this.label_doi2 = new System.Windows.Forms.Label();
            this.label_thoigian = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label_san = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button_them = new System.Windows.Forms.Button();
            this.button_sua = new System.Windows.Forms.Button();
            this.button_xoa = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 222);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_laplichthidau);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 14;
            // 
            // label_laplichthidau
            // 
            this.label_laplichthidau.AutoSize = true;
            this.label_laplichthidau.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_laplichthidau.ForeColor = System.Drawing.Color.White;
            this.label_laplichthidau.Location = new System.Drawing.Point(318, 9);
            this.label_laplichthidau.Name = "label_laplichthidau";
            this.label_laplichthidau.Size = new System.Drawing.Size(226, 37);
            this.label_laplichthidau.TabIndex = 0;
            this.label_laplichthidau.Text = "Lập Lịch Thi Đấu";
            // 
            // comboBox_chonmuagiai
            // 
            this.comboBox_chonmuagiai.FormattingEnabled = true;
            this.comboBox_chonmuagiai.Location = new System.Drawing.Point(164, 325);
            this.comboBox_chonmuagiai.Name = "comboBox_chonmuagiai";
            this.comboBox_chonmuagiai.Size = new System.Drawing.Size(200, 28);
            this.comboBox_chonmuagiai.TabIndex = 34;
            this.comboBox_chonmuagiai.SelectedIndexChanged += new System.EventHandler(this.comboBox_chonmuagiai_SelectedIndexChanged);
            // 
            // label_chonmuagiai
            // 
            this.label_chonmuagiai.AutoSize = true;
            this.label_chonmuagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_chonmuagiai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_chonmuagiai.Location = new System.Drawing.Point(34, 325);
            this.label_chonmuagiai.Name = "label_chonmuagiai";
            this.label_chonmuagiai.Size = new System.Drawing.Size(108, 28);
            this.label_chonmuagiai.TabIndex = 33;
            this.label_chonmuagiai.Text = "Mùa Giải :";
            // 
            // label_vongdau
            // 
            this.label_vongdau.AutoSize = true;
            this.label_vongdau.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_vongdau.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_vongdau.Location = new System.Drawing.Point(460, 325);
            this.label_vongdau.Name = "label_vongdau";
            this.label_vongdau.Size = new System.Drawing.Size(115, 28);
            this.label_vongdau.TabIndex = 35;
            this.label_vongdau.Text = "Vòng Đấu :";
            // 
            // comboBox_vongdau
            // 
            this.comboBox_vongdau.FormattingEnabled = true;
            this.comboBox_vongdau.Items.AddRange(new object[] {
            "Vòng 1",
            "Vòng 2",
            "Vòng cuối"});
            this.comboBox_vongdau.Location = new System.Drawing.Point(607, 325);
            this.comboBox_vongdau.Name = "comboBox_vongdau";
            this.comboBox_vongdau.Size = new System.Drawing.Size(200, 28);
            this.comboBox_vongdau.TabIndex = 36;
            this.comboBox_vongdau.SelectedIndexChanged += new System.EventHandler(this.comboBox_vongdau_SelectedIndexChanged);
            // 
            // comboBox_doi1
            // 
            this.comboBox_doi1.FormattingEnabled = true;
            this.comboBox_doi1.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox_doi1.Location = new System.Drawing.Point(164, 387);
            this.comboBox_doi1.Name = "comboBox_doi1";
            this.comboBox_doi1.Size = new System.Drawing.Size(200, 28);
            this.comboBox_doi1.TabIndex = 38;
            this.comboBox_doi1.SelectedIndexChanged += new System.EventHandler(this.comboBox_doi1_SelectedIndexChanged);
            // 
            // label_doi1
            // 
            this.label_doi1.AutoSize = true;
            this.label_doi1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_doi1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_doi1.Location = new System.Drawing.Point(68, 383);
            this.label_doi1.Name = "label_doi1";
            this.label_doi1.Size = new System.Drawing.Size(74, 28);
            this.label_doi1.TabIndex = 37;
            this.label_doi1.Text = "Đội 1 :";
            // 
            // comboBox_doi2
            // 
            this.comboBox_doi2.FormattingEnabled = true;
            this.comboBox_doi2.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox_doi2.Location = new System.Drawing.Point(607, 387);
            this.comboBox_doi2.Name = "comboBox_doi2";
            this.comboBox_doi2.Size = new System.Drawing.Size(200, 28);
            this.comboBox_doi2.TabIndex = 40;
            this.comboBox_doi2.SelectedIndexChanged += new System.EventHandler(this.comboBox_doi2_SelectedIndexChanged);
            // 
            // label_doi2
            // 
            this.label_doi2.AutoSize = true;
            this.label_doi2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_doi2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_doi2.Location = new System.Drawing.Point(501, 387);
            this.label_doi2.Name = "label_doi2";
            this.label_doi2.Size = new System.Drawing.Size(74, 28);
            this.label_doi2.TabIndex = 39;
            this.label_doi2.Text = "Đội 2 :";
            // 
            // label_thoigian
            // 
            this.label_thoigian.AutoSize = true;
            this.label_thoigian.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_thoigian.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_thoigian.Location = new System.Drawing.Point(27, 446);
            this.label_thoigian.Name = "label_thoigian";
            this.label_thoigian.Size = new System.Drawing.Size(115, 28);
            this.label_thoigian.TabIndex = 41;
            this.label_thoigian.Text = "Thời Gian :";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox2.Location = new System.Drawing.Point(607, 450);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(200, 28);
            this.comboBox2.TabIndex = 44;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label_san
            // 
            this.label_san.AutoSize = true;
            this.label_san.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_san.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_san.Location = new System.Drawing.Point(518, 450);
            this.label_san.Name = "label_san";
            this.label_san.Size = new System.Drawing.Size(57, 28);
            this.label_san.TabIndex = 43;
            this.label_san.Text = "Sân :";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(164, 452);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(250, 27);
            this.dateTimePicker1.TabIndex = 45;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(0, 477);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 46;
            this.pictureBox2.TabStop = false;
            // 
            // dataSet1BindingSource
            // 
            this.dataSet1BindingSource.DataSource = typeof(QLBD.DataSet1);
            this.dataSet1BindingSource.Position = 0;
            // 
            // button_them
            // 
            this.button_them.BackColor = System.Drawing.Color.Green;
            this.button_them.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_them.ForeColor = System.Drawing.Color.White;
            this.button_them.Location = new System.Drawing.Point(423, 502);
            this.button_them.Name = "button_them";
            this.button_them.Size = new System.Drawing.Size(94, 37);
            this.button_them.TabIndex = 47;
            this.button_them.Text = "Thêm";
            this.button_them.UseVisualStyleBackColor = false;
            this.button_them.Click += new System.EventHandler(this.button_them_Click);
            // 
            // button_sua
            // 
            this.button_sua.BackColor = System.Drawing.Color.Yellow;
            this.button_sua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_sua.ForeColor = System.Drawing.Color.White;
            this.button_sua.Location = new System.Drawing.Point(577, 502);
            this.button_sua.Name = "button_sua";
            this.button_sua.Size = new System.Drawing.Size(94, 37);
            this.button_sua.TabIndex = 48;
            this.button_sua.Text = "Sửa";
            this.button_sua.UseVisualStyleBackColor = false;
            // 
            // button_xoa
            // 
            this.button_xoa.BackColor = System.Drawing.Color.Red;
            this.button_xoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_xoa.ForeColor = System.Drawing.Color.White;
            this.button_xoa.Location = new System.Drawing.Point(732, 502);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(94, 37);
            this.button_xoa.TabIndex = 49;
            this.button_xoa.Text = "Xóa";
            this.button_xoa.UseVisualStyleBackColor = false;
            // 
            // laplichthidau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_sua);
            this.Controls.Add(this.button_them);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label_san);
            this.Controls.Add(this.label_thoigian);
            this.Controls.Add(this.comboBox_doi2);
            this.Controls.Add(this.label_doi2);
            this.Controls.Add(this.comboBox_doi1);
            this.Controls.Add(this.label_doi1);
            this.Controls.Add(this.comboBox_vongdau);
            this.Controls.Add(this.label_vongdau);
            this.Controls.Add(this.comboBox_chonmuagiai);
            this.Controls.Add(this.label_chonmuagiai);
            this.Controls.Add(this.panel_themct);
            this.Controls.Add(this.dataGridView1);
            this.Name = "laplichthidau";
            this.Text = "laplichthidau";
            this.Load += new System.EventHandler(this.laplichthidau_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private Panel panel_themct;
        private Label label_laplichthidau;
        private ComboBox comboBox_chonmuagiai;
        private Label label_chonmuagiai;
        private Label label_vongdau;
        private ComboBox comboBox_vongdau;
        private ComboBox comboBox_doi1;
        private Label label_doi1;
        private ComboBox comboBox_doi2;
        private Label label_doi2;
        private Label label_thoigian;
        private ComboBox comboBox2;
        private Label label_san;
        private DateTimePicker dateTimePicker1;
        private PictureBox pictureBox2;
        private BindingSource dataSet1BindingSource;
        private Button button_them;
        private Button button_sua;
        private Button button_xoa;
    }
}