﻿namespace QLBD
{
    partial class thongtindoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_thongtindoi = new System.Windows.Forms.Label();
            this.label_chonmuagiai = new System.Windows.Forms.Label();
            this.label_chondoi = new System.Windows.Forms.Label();
            this.comboBox_chonmuagiai = new System.Windows.Forms.ComboBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox_chondoi = new System.Windows.Forms.ComboBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_thongtindoi);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 13;
            // 
            // label_thongtindoi
            // 
            this.label_thongtindoi.AutoSize = true;
            this.label_thongtindoi.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_thongtindoi.ForeColor = System.Drawing.Color.White;
            this.label_thongtindoi.Location = new System.Drawing.Point(259, 9);
            this.label_thongtindoi.Name = "label_thongtindoi";
            this.label_thongtindoi.Size = new System.Drawing.Size(272, 37);
            this.label_thongtindoi.TabIndex = 0;
            this.label_thongtindoi.Text = "Thông Tin Đội Bóng";
            // 
            // label_chonmuagiai
            // 
            this.label_chonmuagiai.AutoSize = true;
            this.label_chonmuagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_chonmuagiai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_chonmuagiai.Location = new System.Drawing.Point(12, 416);
            this.label_chonmuagiai.Name = "label_chonmuagiai";
            this.label_chonmuagiai.Size = new System.Drawing.Size(108, 28);
            this.label_chonmuagiai.TabIndex = 16;
            this.label_chonmuagiai.Text = "Mùa Giải :";
            // 
            // label_chondoi
            // 
            this.label_chondoi.AutoSize = true;
            this.label_chondoi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_chondoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_chondoi.Location = new System.Drawing.Point(449, 416);
            this.label_chondoi.Name = "label_chondoi";
            this.label_chondoi.Size = new System.Drawing.Size(111, 28);
            this.label_chondoi.TabIndex = 17;
            this.label_chondoi.Text = "Đội Bóng :";
            // 
            // comboBox_chonmuagiai
            // 
            this.comboBox_chonmuagiai.FormattingEnabled = true;
            this.comboBox_chonmuagiai.Location = new System.Drawing.Point(142, 416);
            this.comboBox_chonmuagiai.Name = "comboBox_chonmuagiai";
            this.comboBox_chonmuagiai.Size = new System.Drawing.Size(200, 28);
            this.comboBox_chonmuagiai.TabIndex = 32;
            this.comboBox_chonmuagiai.SelectedIndexChanged += new System.EventHandler(this.comboBox_chonmuagiai_SelectedIndexChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 309);
            this.dataGridView1.TabIndex = 33;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // comboBox_chondoi
            // 
            this.comboBox_chondoi.FormattingEnabled = true;
            this.comboBox_chondoi.Location = new System.Drawing.Point(591, 416);
            this.comboBox_chondoi.Name = "comboBox_chondoi";
            this.comboBox_chondoi.Size = new System.Drawing.Size(200, 28);
            this.comboBox_chondoi.TabIndex = 34;
            this.comboBox_chondoi.SelectedIndexChanged += new System.EventHandler(this.comboBox_chondoi_SelectedIndexChanged);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(0, 492);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 35;
            this.pictureBox2.TabStop = false;
            // 
            // thongtindoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.comboBox_chondoi);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBox_chonmuagiai);
            this.Controls.Add(this.label_chondoi);
            this.Controls.Add(this.label_chonmuagiai);
            this.Controls.Add(this.panel_themct);
            this.MinimumSize = new System.Drawing.Size(874, 603);
            this.Name = "thongtindoi";
            this.Text = "Thông Tin Đội Bóng";
            this.Load += new System.EventHandler(this.thongtindoi_Load);
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel_themct;
        private Label label_thongtindoi;
        private Label label_chonmuagiai;
        private Label label_chondoi;
        private ComboBox comboBox_chonmuagiai;
        private DataGridView dataGridView1;
        private ComboBox comboBox_chondoi;
        private PictureBox pictureBox2;
    }
}