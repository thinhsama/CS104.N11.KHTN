﻿namespace QLBD
{
    partial class dangkydoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label_tendoi = new System.Windows.Forms.Label();
            this.textBox_tendoi = new System.Windows.Forms.TextBox();
            this.label_muagiai = new System.Windows.Forms.Label();
            this.label_sannha = new System.Windows.Forms.Label();
            this.label_succhua = new System.Windows.Forms.Label();
            this.textBox_succhua = new System.Windows.Forms.TextBox();
            this.textBox_sannha = new System.Windows.Forms.TextBox();
            this.label_diachi = new System.Windows.Forms.Label();
            this.textBox_diachi = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dataSet1BindingSource5 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.panel_register = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button_them = new System.Windows.Forms.Button();
            this.button_xoa = new System.Windows.Forms.Button();
            this.button_sua = new System.Windows.Forms.Button();
            this.dataGridView_DOIBONG = new System.Windows.Forms.DataGridView();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.dataSet1BindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource4)).BeginInit();
            this.panel_register.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DOIBONG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource3)).BeginInit();
            this.SuspendLayout();
            // 
            // label_tendoi
            // 
            this.label_tendoi.AutoSize = true;
            this.label_tendoi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_tendoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_tendoi.Location = new System.Drawing.Point(12, 333);
            this.label_tendoi.Name = "label_tendoi";
            this.label_tendoi.Size = new System.Drawing.Size(93, 28);
            this.label_tendoi.TabIndex = 0;
            this.label_tendoi.Text = "Tên đội :";
            // 
            // textBox_tendoi
            // 
            this.textBox_tendoi.Location = new System.Drawing.Point(111, 337);
            this.textBox_tendoi.Name = "textBox_tendoi";
            this.textBox_tendoi.Size = new System.Drawing.Size(200, 27);
            this.textBox_tendoi.TabIndex = 1;
            this.textBox_tendoi.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label_muagiai
            // 
            this.label_muagiai.AutoSize = true;
            this.label_muagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_muagiai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_muagiai.Location = new System.Drawing.Point(475, 333);
            this.label_muagiai.Name = "label_muagiai";
            this.label_muagiai.Size = new System.Drawing.Size(108, 28);
            this.label_muagiai.TabIndex = 2;
            this.label_muagiai.Text = "Mùa Giải :";
            // 
            // label_sannha
            // 
            this.label_sannha.AutoSize = true;
            this.label_sannha.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_sannha.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_sannha.Location = new System.Drawing.Point(3, 382);
            this.label_sannha.Name = "label_sannha";
            this.label_sannha.Size = new System.Drawing.Size(102, 28);
            this.label_sannha.TabIndex = 3;
            this.label_sannha.Text = "Sân Nhà :";
            this.label_sannha.Click += new System.EventHandler(this.label2_Click);
            // 
            // label_succhua
            // 
            this.label_succhua.AutoSize = true;
            this.label_succhua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_succhua.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_succhua.Location = new System.Drawing.Point(472, 382);
            this.label_succhua.Name = "label_succhua";
            this.label_succhua.Size = new System.Drawing.Size(111, 28);
            this.label_succhua.TabIndex = 4;
            this.label_succhua.Text = "Sức Chứa :";
            // 
            // textBox_succhua
            // 
            this.textBox_succhua.Location = new System.Drawing.Point(603, 386);
            this.textBox_succhua.Name = "textBox_succhua";
            this.textBox_succhua.Size = new System.Drawing.Size(200, 27);
            this.textBox_succhua.TabIndex = 5;
            // 
            // textBox_sannha
            // 
            this.textBox_sannha.Location = new System.Drawing.Point(111, 386);
            this.textBox_sannha.Name = "textBox_sannha";
            this.textBox_sannha.Size = new System.Drawing.Size(200, 27);
            this.textBox_sannha.TabIndex = 6;
            // 
            // label_diachi
            // 
            this.label_diachi.AutoSize = true;
            this.label_diachi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_diachi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_diachi.Location = new System.Drawing.Point(14, 431);
            this.label_diachi.Name = "label_diachi";
            this.label_diachi.Size = new System.Drawing.Size(91, 28);
            this.label_diachi.TabIndex = 7;
            this.label_diachi.Text = "Địa Chỉ :";
            // 
            // textBox_diachi
            // 
            this.textBox_diachi.Location = new System.Drawing.Point(113, 435);
            this.textBox_diachi.Name = "textBox_diachi";
            this.textBox_diachi.Size = new System.Drawing.Size(690, 27);
            this.textBox_diachi.TabIndex = 8;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(603, 337);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 28);
            this.comboBox1.TabIndex = 9;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // dataSet1BindingSource5
            // 
            this.dataSet1BindingSource5.DataSource = typeof(QLBD.DataSet1);
            this.dataSet1BindingSource5.Position = 0;
            // 
            // dataSet1BindingSource4
            // 
            this.dataSet1BindingSource4.DataSource = typeof(QLBD.DataSet1);
            this.dataSet1BindingSource4.Position = 0;
            this.dataSet1BindingSource4.CurrentChanged += new System.EventHandler(this.dataSet1BindingSource4_CurrentChanged);
            // 
            // panel_register
            // 
            this.panel_register.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_register.Controls.Add(this.label1);
            this.panel_register.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_register.Location = new System.Drawing.Point(0, 0);
            this.panel_register.Name = "panel_register";
            this.panel_register.Size = new System.Drawing.Size(856, 61);
            this.panel_register.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(340, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(176, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "Đăng Ký Đội";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button_them
            // 
            this.button_them.BackColor = System.Drawing.Color.Green;
            this.button_them.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_them.ForeColor = System.Drawing.Color.White;
            this.button_them.Location = new System.Drawing.Point(422, 485);
            this.button_them.Name = "button_them";
            this.button_them.Size = new System.Drawing.Size(94, 37);
            this.button_them.TabIndex = 12;
            this.button_them.Text = "Thêm";
            this.button_them.UseVisualStyleBackColor = false;
            this.button_them.Click += new System.EventHandler(this.button_them_Click);
            // 
            // button_xoa
            // 
            this.button_xoa.BackColor = System.Drawing.Color.Red;
            this.button_xoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_xoa.ForeColor = System.Drawing.Color.White;
            this.button_xoa.Location = new System.Drawing.Point(709, 485);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(94, 37);
            this.button_xoa.TabIndex = 13;
            this.button_xoa.Text = "Xóa";
            this.button_xoa.UseVisualStyleBackColor = false;
            this.button_xoa.Click += new System.EventHandler(this.button_xoa_Click);
            // 
            // button_sua
            // 
            this.button_sua.BackColor = System.Drawing.Color.Yellow;
            this.button_sua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_sua.ForeColor = System.Drawing.Color.White;
            this.button_sua.Location = new System.Drawing.Point(566, 485);
            this.button_sua.Name = "button_sua";
            this.button_sua.Size = new System.Drawing.Size(94, 37);
            this.button_sua.TabIndex = 14;
            this.button_sua.Text = "Sửa";
            this.button_sua.UseVisualStyleBackColor = false;
            this.button_sua.Click += new System.EventHandler(this.button_sua_Click);
            // 
            // dataGridView_DOIBONG
            // 
            this.dataGridView_DOIBONG.AllowUserToAddRows = false;
            this.dataGridView_DOIBONG.AllowUserToDeleteRows = false;
            this.dataGridView_DOIBONG.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridView_DOIBONG.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_DOIBONG.Location = new System.Drawing.Point(9, 76);
            this.dataGridView_DOIBONG.Name = "dataGridView_DOIBONG";
            this.dataGridView_DOIBONG.ReadOnly = true;
            this.dataGridView_DOIBONG.RowHeadersWidth = 51;
            this.dataGridView_DOIBONG.RowTemplate.Height = 29;
            this.dataGridView_DOIBONG.Size = new System.Drawing.Size(835, 232);
            this.dataGridView_DOIBONG.TabIndex = 15;
            this.dataGridView_DOIBONG.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_DOIBONG_CellContentClick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(0, 496);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 16;
            this.pictureBox2.TabStop = false;
            // 
            // dataSet1BindingSource
            // 
            this.dataSet1BindingSource.DataSource = typeof(QLBD.DataSet1);
            this.dataSet1BindingSource.Position = 0;
            // 
            // dataSet1BindingSource1
            // 
            this.dataSet1BindingSource1.DataSource = typeof(QLBD.DataSet1);
            this.dataSet1BindingSource1.Position = 0;
            // 
            // dataSet1BindingSource2
            // 
            this.dataSet1BindingSource2.DataSource = typeof(QLBD.DataSet1);
            this.dataSet1BindingSource2.Position = 0;
            // 
            // dataSet1BindingSource3
            // 
            this.dataSet1BindingSource3.DataSource = typeof(QLBD.DataSet1);
            this.dataSet1BindingSource3.Position = 0;
            // 
            // dangkydoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.dataGridView_DOIBONG);
            this.Controls.Add(this.button_sua);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_them);
            this.Controls.Add(this.panel_register);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox_diachi);
            this.Controls.Add(this.label_diachi);
            this.Controls.Add(this.textBox_sannha);
            this.Controls.Add(this.textBox_succhua);
            this.Controls.Add(this.label_succhua);
            this.Controls.Add(this.label_sannha);
            this.Controls.Add(this.label_muagiai);
            this.Controls.Add(this.textBox_tendoi);
            this.Controls.Add(this.label_tendoi);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MinimumSize = new System.Drawing.Size(874, 603);
            this.Name = "dangkydoi";
            this.Text = "Đăng Ký Đội";
            this.Load += new System.EventHandler(this.dangkydoi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource4)).EndInit();
            this.panel_register.ResumeLayout(false);
            this.panel_register.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_DOIBONG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet1BindingSource3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label_tendoi;
        private TextBox textBox_tendoi;
        private Label label_muagiai;
        private Label label_sannha;
        private Label label_succhua;
        private TextBox textBox_succhua;
        private TextBox textBox_sannha;
        private Label label_diachi;
        private TextBox textBox_diachi;
        private ComboBox comboBox1;
        private Panel panel_register;
        private Label label1;
        private Button button_them;
        private Button button_xoa;
        private Button button_sua;
        private DataGridView dataGridView_DOIBONG;
        private DataGridViewTextBoxColumn TENMUA;
        private DataGridViewTextBoxColumn TENSAN;
        private DataGridViewTextBoxColumn SUCCHUA;
        private DataGridViewTextBoxColumn DIACHI;
        private PictureBox pictureBox2;
        private BindingSource dataSet1BindingSource;
        private BindingSource dataSet1BindingSource4;
        private BindingSource dataSet1BindingSource1;
        private BindingSource dataSet1BindingSource2;
        private BindingSource dataSet1BindingSource3;
        private BindingSource dataSet1BindingSource5;
    }
}