﻿namespace QLBD
{
    partial class loaict
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_dsgb = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox_tenloaict = new System.Windows.Forms.TextBox();
            this.label_tdghibantoida = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_xoa = new System.Windows.Forms.Button();
            this.button_sua = new System.Windows.Forms.Button();
            this.button_them = new System.Windows.Forms.Button();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_dsgb);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 18;
            // 
            // label_dsgb
            // 
            this.label_dsgb.AutoSize = true;
            this.label_dsgb.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_dsgb.ForeColor = System.Drawing.Color.White;
            this.label_dsgb.Location = new System.Drawing.Point(272, 9);
            this.label_dsgb.Name = "label_dsgb";
            this.label_dsgb.Size = new System.Drawing.Size(306, 37);
            this.label_dsgb.TabIndex = 0;
            this.label_dsgb.Text = "Quy Định Loại Cầu Thủ";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 162);
            this.dataGridView1.TabIndex = 19;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // textBox_tenloaict
            // 
            this.textBox_tenloaict.Location = new System.Drawing.Point(293, 314);
            this.textBox_tenloaict.Name = "textBox_tenloaict";
            this.textBox_tenloaict.Size = new System.Drawing.Size(200, 27);
            this.textBox_tenloaict.TabIndex = 34;
            // 
            // label_tdghibantoida
            // 
            this.label_tdghibantoida.AutoSize = true;
            this.label_tdghibantoida.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_tdghibantoida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_tdghibantoida.Location = new System.Drawing.Point(12, 310);
            this.label_tdghibantoida.Name = "label_tdghibantoida";
            this.label_tdghibantoida.Size = new System.Drawing.Size(184, 28);
            this.label_tdghibantoida.TabIndex = 33;
            this.label_tdghibantoida.Text = "Tên Loại Cầu Thủ :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(0, 495);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 45;
            this.pictureBox2.TabStop = false;
            // 
            // button_xoa
            // 
            this.button_xoa.BackColor = System.Drawing.Color.Red;
            this.button_xoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_xoa.ForeColor = System.Drawing.Color.White;
            this.button_xoa.Location = new System.Drawing.Point(675, 495);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(94, 37);
            this.button_xoa.TabIndex = 44;
            this.button_xoa.Text = "Xóa";
            this.button_xoa.UseVisualStyleBackColor = false;
            // 
            // button_sua
            // 
            this.button_sua.BackColor = System.Drawing.Color.Yellow;
            this.button_sua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_sua.ForeColor = System.Drawing.Color.White;
            this.button_sua.Location = new System.Drawing.Point(523, 495);
            this.button_sua.Name = "button_sua";
            this.button_sua.Size = new System.Drawing.Size(94, 37);
            this.button_sua.TabIndex = 43;
            this.button_sua.Text = "Sửa";
            this.button_sua.UseVisualStyleBackColor = false;
            // 
            // button_them
            // 
            this.button_them.BackColor = System.Drawing.Color.Green;
            this.button_them.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_them.ForeColor = System.Drawing.Color.White;
            this.button_them.Location = new System.Drawing.Point(361, 495);
            this.button_them.Name = "button_them";
            this.button_them.Size = new System.Drawing.Size(94, 37);
            this.button_them.TabIndex = 42;
            this.button_them.Text = "Thêm";
            this.button_them.UseVisualStyleBackColor = false;
            this.button_them.Click += new System.EventHandler(this.button_them_Click);
            // 
            // loaict
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_sua);
            this.Controls.Add(this.button_them);
            this.Controls.Add(this.textBox_tenloaict);
            this.Controls.Add(this.label_tdghibantoida);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel_themct);
            this.MinimumSize = new System.Drawing.Size(874, 603);
            this.Name = "loaict";
            this.Text = "loaict";
            this.Load += new System.EventHandler(this.loaict_Load);
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel_themct;
        private Label label_dsgb;
        private DataGridView dataGridView1;
        private TextBox textBox_tenloaict;
        private Label label_tdghibantoida;
        private PictureBox pictureBox2;
        private Button button_xoa;
        private Button button_sua;
        private Button button_them;
    }
}