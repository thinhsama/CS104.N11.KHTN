﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QLBD
{
    public partial class ghinhan : Form
    {
        public ghinhan()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT MAKQ as 'Mã KQ', TENDOI1 as 'Tên đội 1', TENDOI2 as 'Tên đội 2', BTDOI1 as 'Bàn thắng đội 1', BTDOI2 as 'Bàn thắng đội 2', TENVONG as 'Vòng', TENMUA as 'Mùa', THOILUONG as 'Thời lượng' FROM KETQUA";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }
        private void label_tiso_Click(object sender, EventArgs e)
        {

        }

        public void display_comboBox1()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox1.DisplayMember = "TENDOI";
            comboBox1.DataSource = dt;
        }

        public void display_comboBox2()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox2.DisplayMember = "TENDOI";
            comboBox2.DataSource = dt;
        }

        /*public void display_comboBox_doi2()
        {
            string query = "SELECT TENDOI FROM KETQUA";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_doi2.DisplayMember = "TENDOI";
            comboBox_doi2.DataSource = dt;
        }*/

        private void ghinhan_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            loaddata();
            display_comboBox_chonmuagiai();
            //display_comboBox_vongdau();
            display_comboBox1();
            display_comboBox2();
            //table.Clear();
            ///adapter.Fill(table);
            //dataGridView1.DataSource = table;
        }

        /*private void comboBox_doi1_TextChanged(object sender, EventArgs e)
        {

        }*/

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        /*public void display_comboBox_vongdau()
        {
            string query = "SELECT TENVONG FROM TRANDAU";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox1.DisplayMember = "TENMUA";
            comboBox1.DataSource = dt;
        }*/

        private void comboBox_vongdau_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void display_comboBox_chonmuagiai()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_chonmuagiai.DisplayMember = "TENMUA";
            comboBox_chonmuagiai.DataSource = dt;
        }

        private void comboBox_chonmuagiai_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        static int i = 1;

        private void button_them_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "INSERT INTO KETQUA(MAKQ, TENDOI1, TENDOI2, BTDOI1, BTDOI2, TENVONG, TENMUA, THOILUONG) VALUES(@MAKQ, @TENDOI1, @TENDOI2, @BTDOI1, @BTDOI2, @TENVONG, @TENMUA, @THOILUONG)";
            command.Parameters.AddWithValue("@MAKQ", i);
            command.Parameters.AddWithValue("@TENDOI1", comboBox1.Text);
            command.Parameters.AddWithValue("@TENDOI2", comboBox2.Text);
            command.Parameters.AddWithValue("@BTDOI1", textBox_btdoi1.Text);
            command.Parameters.AddWithValue("@BTDOI2", textBox_btdoi2.Text);
            command.Parameters.AddWithValue("@TENVONG", comboBox_vongdau.Text);
            command.Parameters.AddWithValue("@TENMUA", comboBox_chonmuagiai.Text);
            command.Parameters.AddWithValue("@THOILUONG", textBox3.Text);

            i++;
            command.ExecuteNonQuery();
            loaddata();
        }

        private void textBox_btdoi1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_btdoi2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
