﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class loaict : Form
    {
        public loaict()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        public void load_data()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM LOAICT";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void loaict_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            load_data();
        }

        static int i = 5;
        private void button_them_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "INSERT INTO LOAICT VALUES(@MALOAI, @TENLOAI)";
            command.Parameters.AddWithValue("@MALOAI", i);
            command.Parameters.AddWithValue("@TENLOAI", textBox_tenloaict.Text);
            command.ExecuteNonQuery();
            i++;
            load_data();
        }
    }
}
