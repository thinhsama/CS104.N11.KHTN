namespace QLBD
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void customizeDesign()
        {
            panel_qlgsubmenu.Visible = false;
            panel_kqsubmenu.Visible = false;
            panel_ltdsubmenu.Visible = false;
            panel_tbsubmenu.Visible = false;
            panel_qdsubmenu.Visible = false;
        }

        private void hideSubmenu()
        {
            if (panel_qlgsubmenu.Visible) panel_qlgsubmenu.Visible = false;
            if (panel_kqsubmenu.Visible) panel_kqsubmenu.Visible = false;
            if (panel_ltdsubmenu.Visible) panel_ltdsubmenu.Visible = false;
            if (panel_tbsubmenu.Visible) panel_tbsubmenu.Visible = false;
            if (panel_qdsubmenu.Visible) panel_qdsubmenu.Visible = false;
        }

        private void showSubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hideSubmenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;
        }
        private void button_qlg_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_qlgsubmenu);
        }
        #region qlg_submenu

        private void button_quanlidoi_Click(object sender, EventArgs e)
        {
            openChildForm(new dangkydoi());
            hideSubmenu();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openChildForm(new themctvaodoi());
            hideSubmenu();
        }

        private void button_thongtindoi_Click(object sender, EventArgs e)
        {
            openChildForm(new thongtindoi());
            hideSubmenu();
        }
        #endregion qlg_submenu

        private void button_lichthidau_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_ltdsubmenu);
        }
        #region ltd_submenu
        private void button_laplichtd_Click(object sender, EventArgs e)
        {
            openChildForm(new laplichthidau());
            hideSubmenu();
        }

        private void button_xemlichtd_Click(object sender, EventArgs e)
        {
            openChildForm(new xemlichthidau());
            hideSubmenu();
        }
        #endregion ltd_submenu
        private void button_kqthidau_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_kqsubmenu);
        }
        #region kq_submenu
        private void button_ghinhan_Click(object sender, EventArgs e)
        {
            openChildForm(new ghinhan());
            hideSubmenu();
        }

        private void button_themct_Click(object sender, EventArgs e)
        {
            openChildForm(new themctghiban());
            hideSubmenu();
        }

        private void button_xemkq_Click(object sender, EventArgs e)
        {
            openChildForm(new xemkqtd());
            hideSubmenu();
        }
        #endregion kq_submenu
        private void button_trabao_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_tbsubmenu);
        }
        #region trabao_submenu
        private void button_bangxh_Click(object sender, EventArgs e)
        {
            openChildForm(new bangxephang());
            hideSubmenu();
        }

        private void button_dsghiban_Click(object sender, EventArgs e)
        {
            openChildForm(new danhsachghiban());
            hideSubmenu();
        }

        private void button_timkiem_Click(object sender, EventArgs e)
        {
            openChildForm(new timkiem());
            hideSubmenu();
        }
        #endregion trabao_submenu
        private void button_quydinh_Click(object sender, EventArgs e)
        {
            showSubmenu(panel_qdsubmenu);
        }
        #region qd_submenu
        private void button_quydinhct_Click(object sender, EventArgs e)
        {
            openChildForm(new quydinhct());
            hideSubmenu();
        }

        private void button_qdbanthang_Click(object sender, EventArgs e)
        {
            openChildForm(new qdbanthang());
            hideSubmenu();
        }

        private void button_qdloaicauthu_Click(object sender, EventArgs e)
        {
            openChildForm(new loaict());
            hideSubmenu();
        }

        private void button_vongdau_Click(object sender, EventArgs e)
        {
            openChildForm(new vongdau());
            hideSubmenu();
        }

        private void button_muagiai_Click(object sender, EventArgs e)
        {
            openChildForm(new muagiai());
            hideSubmenu();
        }
        #endregion qd_submenu

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private Form activeform = null;
        private void openChildForm(Form childForm)
        {
            if(activeform != null)
                activeform.Close();
            activeform = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            panel_main.Controls.Add(childForm);
            panel_main.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void panel_logo_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void button_quaylai_Click(object sender, EventArgs e)
        {
            openChildForm(new Manhinhchinh());
            hideSubmenu();
        }

        private void button_backtrabao_Click(object sender, EventArgs e)
        {
            openChildForm(new Manhinhchinh());
            hideSubmenu();
        }

        private void button_backqlg_Click(object sender, EventArgs e)
        {
            openChildForm(new Manhinhchinh());
            hideSubmenu();
        }

        private void button_backltd_Click(object sender, EventArgs e)
        {
            openChildForm(new Manhinhchinh());
            hideSubmenu();
        }

        private void button_backkq_Click(object sender, EventArgs e)
        {
            openChildForm(new Manhinhchinh());
            hideSubmenu();
        }
    }
}