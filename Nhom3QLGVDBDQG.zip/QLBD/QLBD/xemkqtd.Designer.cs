﻿namespace QLBD
{
    partial class xemkqtd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_ghinhankq = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox_trandau = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label_muagiai = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_ghinhankq);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 17;
            // 
            // label_ghinhankq
            // 
            this.label_ghinhankq.AutoSize = true;
            this.label_ghinhankq.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_ghinhankq.ForeColor = System.Drawing.Color.White;
            this.label_ghinhankq.Location = new System.Drawing.Point(304, 9);
            this.label_ghinhankq.Name = "label_ghinhankq";
            this.label_ghinhankq.Size = new System.Drawing.Size(240, 37);
            this.label_ghinhankq.TabIndex = 0;
            this.label_ghinhankq.Text = "Kết Quả Trận Đấu";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 242);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // comboBox_trandau
            // 
            this.comboBox_trandau.FormattingEnabled = true;
            this.comboBox_trandau.Items.AddRange(new object[] {
            "Vòng 1",
            "Vòng 2",
            "Vòng cuối"});
            this.comboBox_trandau.Location = new System.Drawing.Point(644, 419);
            this.comboBox_trandau.Name = "comboBox_trandau";
            this.comboBox_trandau.Size = new System.Drawing.Size(200, 28);
            this.comboBox_trandau.TabIndex = 23;
            this.comboBox_trandau.SelectedIndexChanged += new System.EventHandler(this.comboBox_trandau_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label1.Location = new System.Drawing.Point(504, 415);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 28);
            this.label1.TabIndex = 22;
            this.label1.Text = "Vòng Đấu :";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox1.Location = new System.Drawing.Point(150, 419);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 28);
            this.comboBox1.TabIndex = 21;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label_muagiai
            // 
            this.label_muagiai.AutoSize = true;
            this.label_muagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_muagiai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_muagiai.Location = new System.Drawing.Point(22, 415);
            this.label_muagiai.Name = "label_muagiai";
            this.label_muagiai.Size = new System.Drawing.Size(108, 28);
            this.label_muagiai.TabIndex = 20;
            this.label_muagiai.Text = "Mùa Giải :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(12, 482);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 59;
            this.pictureBox2.TabStop = false;
            // 
            // xemkqtd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.comboBox_trandau);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label_muagiai);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel_themct);
            this.Name = "xemkqtd";
            this.Text = "xemkqtd";
            this.Load += new System.EventHandler(this.xemkqtd_Load);
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel_themct;
        private Label label_ghinhankq;
        private DataGridView dataGridView1;
        private ComboBox comboBox_trandau;
        private Label label1;
        private ComboBox comboBox1;
        private Label label_muagiai;
        private PictureBox pictureBox2;
    }
}