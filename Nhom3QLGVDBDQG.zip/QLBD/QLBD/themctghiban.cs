﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class themctghiban : Form
    {
        public themctghiban()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        void load_data()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT TENMUA as 'Mùa', TENVONG as 'Vòng', TENCT as 'Tên cầu thủ', LOAIBT as 'Loại bàn thắng' FROM GHINHAN";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        public void display_comboBox1()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox1.DisplayMember = "TENMUA";
            comboBox1.DataSource = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_trandau_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void display_comboBox_cauthu()
        {
            string query = "SELECT TENCT FROM CAUTHU";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_cauthu.DisplayMember = "TENCT";
            comboBox_cauthu.DataSource = dt;
        }

        private void comboBox_cauthu_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void themctghiban_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            load_data();
            display_comboBox_cauthu();
            display_comboBox1();
        }

        //static int i = 1;

        private void button_them_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "INSERT INTO GHINHAN VALUES(@TENMUA, @TENVONG, @TENCT, @LOAIBT)";
            command.Parameters.AddWithValue("@TENMUA", comboBox1.Text);
            command.Parameters.AddWithValue("@TENVONG", comboBox_trandau.Text);
            command.Parameters.AddWithValue("@TENCT", comboBox_cauthu.Text);
            command.Parameters.AddWithValue("@LOAIBT", comboBox2.Text);

            //i++;
            command.ExecuteNonQuery();
            load_data();
        }

        private void button_sua_Click(object sender, EventArgs e)
        {

        }

        private void button_xoa_Click(object sender, EventArgs e)
        {

        }
    }
}
