﻿namespace QLBD
{
    partial class quydinhct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_dsgb = new System.Windows.Forms.Label();
            this.label_tuoitt = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox_tuoitt = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label_tuoitd = new System.Windows.Forms.Label();
            this.textBox_socttt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label_socttd = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_xoa = new System.Windows.Forms.Button();
            this.button_sua = new System.Windows.Forms.Button();
            this.button_them = new System.Windows.Forms.Button();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_dsgb);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 16;
            // 
            // label_dsgb
            // 
            this.label_dsgb.AutoSize = true;
            this.label_dsgb.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_dsgb.ForeColor = System.Drawing.Color.White;
            this.label_dsgb.Location = new System.Drawing.Point(309, 9);
            this.label_dsgb.Name = "label_dsgb";
            this.label_dsgb.Size = new System.Drawing.Size(245, 37);
            this.label_dsgb.TabIndex = 0;
            this.label_dsgb.Text = "Quy Định Cầu Thủ";
            // 
            // label_tuoitt
            // 
            this.label_tuoitt.AutoSize = true;
            this.label_tuoitt.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_tuoitt.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_tuoitt.Location = new System.Drawing.Point(12, 255);
            this.label_tuoitt.Name = "label_tuoitt";
            this.label_tuoitt.Size = new System.Drawing.Size(159, 28);
            this.label_tuoitt.TabIndex = 27;
            this.label_tuoitt.Text = "Tuổi Tối Thiểu :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 154);
            this.dataGridView1.TabIndex = 28;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // textBox_tuoitt
            // 
            this.textBox_tuoitt.Location = new System.Drawing.Point(208, 256);
            this.textBox_tuoitt.Name = "textBox_tuoitt";
            this.textBox_tuoitt.Size = new System.Drawing.Size(200, 27);
            this.textBox_tuoitt.TabIndex = 29;
            this.textBox_tuoitt.TextChanged += new System.EventHandler(this.textBox_tuoitt_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(640, 257);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(200, 27);
            this.textBox2.TabIndex = 31;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label_tuoitd
            // 
            this.label_tuoitd.AutoSize = true;
            this.label_tuoitd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_tuoitd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_tuoitd.Location = new System.Drawing.Point(466, 256);
            this.label_tuoitd.Name = "label_tuoitd";
            this.label_tuoitd.Size = new System.Drawing.Size(132, 28);
            this.label_tuoitd.TabIndex = 30;
            this.label_tuoitd.Text = "Tuổi Tối Đa :";
            // 
            // textBox_socttt
            // 
            this.textBox_socttt.Location = new System.Drawing.Point(208, 330);
            this.textBox_socttt.Name = "textBox_socttt";
            this.textBox_socttt.Size = new System.Drawing.Size(200, 27);
            this.textBox_socttt.TabIndex = 33;
            this.textBox_socttt.TextChanged += new System.EventHandler(this.textBox_socttt_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label1.Location = new System.Drawing.Point(0, 331);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 28);
            this.label1.TabIndex = 32;
            this.label1.Text = "Số CT Tối Thiểu :";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(640, 331);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(200, 27);
            this.textBox3.TabIndex = 35;
            // 
            // label_socttd
            // 
            this.label_socttd.AutoSize = true;
            this.label_socttd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_socttd.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_socttd.Location = new System.Drawing.Point(454, 330);
            this.label_socttd.Name = "label_socttd";
            this.label_socttd.Size = new System.Drawing.Size(144, 28);
            this.label_socttd.TabIndex = 34;
            this.label_socttd.Text = "Số CT Tối Đa :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(324, 414);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(200, 27);
            this.textBox1.TabIndex = 37;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label2.Location = new System.Drawing.Point(12, 410);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(265, 28);
            this.label2.TabIndex = 36;
            this.label2.Text = "Số CT Nước Ngoài Tối Đa :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(0, 497);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 41;
            this.pictureBox2.TabStop = false;
            // 
            // button_xoa
            // 
            this.button_xoa.BackColor = System.Drawing.Color.Red;
            this.button_xoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_xoa.ForeColor = System.Drawing.Color.White;
            this.button_xoa.Location = new System.Drawing.Point(675, 497);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(94, 37);
            this.button_xoa.TabIndex = 40;
            this.button_xoa.Text = "Xóa";
            this.button_xoa.UseVisualStyleBackColor = false;
            this.button_xoa.Click += new System.EventHandler(this.button_xoa_Click);
            // 
            // button_sua
            // 
            this.button_sua.BackColor = System.Drawing.Color.Yellow;
            this.button_sua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_sua.ForeColor = System.Drawing.Color.White;
            this.button_sua.Location = new System.Drawing.Point(523, 497);
            this.button_sua.Name = "button_sua";
            this.button_sua.Size = new System.Drawing.Size(94, 37);
            this.button_sua.TabIndex = 39;
            this.button_sua.Text = "Sửa";
            this.button_sua.UseVisualStyleBackColor = false;
            // 
            // button_them
            // 
            this.button_them.BackColor = System.Drawing.Color.Green;
            this.button_them.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_them.ForeColor = System.Drawing.Color.White;
            this.button_them.Location = new System.Drawing.Point(361, 497);
            this.button_them.Name = "button_them";
            this.button_them.Size = new System.Drawing.Size(94, 37);
            this.button_them.TabIndex = 38;
            this.button_them.Text = "Thêm";
            this.button_them.UseVisualStyleBackColor = false;
            this.button_them.Click += new System.EventHandler(this.button_them_Click);
            // 
            // quydinhct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_sua);
            this.Controls.Add(this.button_them);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label_socttd);
            this.Controls.Add(this.textBox_socttt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label_tuoitd);
            this.Controls.Add(this.textBox_tuoitt);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label_tuoitt);
            this.Controls.Add(this.panel_themct);
            this.MinimumSize = new System.Drawing.Size(874, 603);
            this.Name = "quydinhct";
            this.Text = "quydinhct";
            this.Load += new System.EventHandler(this.quydinhct_Load);
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel_themct;
        private Label label_dsgb;
        private Label label_tuoitt;
        private DataGridView dataGridView1;
        private TextBox textBox_tuoitt;
        private TextBox textBox2;
        private Label label_tuoitd;
        private TextBox textBox_socttt;
        private Label label1;
        private TextBox textBox3;
        private Label label_socttd;
        private TextBox textBox1;
        private Label label2;
        private PictureBox pictureBox2;
        private Button button_xoa;
        private Button button_sua;
        private Button button_them;
    }
}