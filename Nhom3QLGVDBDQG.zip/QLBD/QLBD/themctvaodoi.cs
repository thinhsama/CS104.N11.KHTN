﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class themctvaodoi : Form
    {
        public themctvaodoi()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            textBox_hoten.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textBox_loaict.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
            textBox_quoctich.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            textBox_ngaysinh.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            textBox_ghichu.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
        }
        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM CAUTHU";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        public void display_comboBox_chondoi()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_chondoi.DisplayMember = "TENDOI";
            comboBox_chondoi.DataSource = dt;
        }

        private void comboBox_chondoi_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void themctvaodoi_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            loaddata();
            display_comboBox_chondoi();
        }
    }
}
