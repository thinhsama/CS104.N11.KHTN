﻿namespace QLBD
{
    partial class danhsachghiban
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_dsgb = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label_muagiai = new System.Windows.Forms.Label();
            this.comboBox_doibong = new System.Windows.Forms.ComboBox();
            this.label_doibong = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_dsgb);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 15;
            // 
            // label_dsgb
            // 
            this.label_dsgb.AutoSize = true;
            this.label_dsgb.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_dsgb.ForeColor = System.Drawing.Color.White;
            this.label_dsgb.Location = new System.Drawing.Point(309, 9);
            this.label_dsgb.Name = "label_dsgb";
            this.label_dsgb.Size = new System.Drawing.Size(255, 37);
            this.label_dsgb.TabIndex = 0;
            this.label_dsgb.Text = "Danh Sách Ghi Bàn";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 258);
            this.dataGridView1.TabIndex = 16;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(155, 376);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 28);
            this.comboBox1.TabIndex = 27;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label_muagiai
            // 
            this.label_muagiai.AutoSize = true;
            this.label_muagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_muagiai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_muagiai.Location = new System.Drawing.Point(12, 372);
            this.label_muagiai.Name = "label_muagiai";
            this.label_muagiai.Size = new System.Drawing.Size(108, 28);
            this.label_muagiai.TabIndex = 26;
            this.label_muagiai.Text = "Mùa Giải :";
            // 
            // comboBox_doibong
            // 
            this.comboBox_doibong.FormattingEnabled = true;
            this.comboBox_doibong.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox_doibong.Location = new System.Drawing.Point(641, 376);
            this.comboBox_doibong.Name = "comboBox_doibong";
            this.comboBox_doibong.Size = new System.Drawing.Size(200, 28);
            this.comboBox_doibong.TabIndex = 29;
            this.comboBox_doibong.SelectedIndexChanged += new System.EventHandler(this.comboBox_doibong_SelectedIndexChanged);
            // 
            // label_doibong
            // 
            this.label_doibong.AutoSize = true;
            this.label_doibong.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_doibong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_doibong.Location = new System.Drawing.Point(498, 372);
            this.label_doibong.Name = "label_doibong";
            this.label_doibong.Size = new System.Drawing.Size(111, 28);
            this.label_doibong.TabIndex = 28;
            this.label_doibong.Text = "Đội Bóng :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(12, 482);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 32;
            this.pictureBox2.TabStop = false;
            // 
            // danhsachghiban
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.comboBox_doibong);
            this.Controls.Add(this.label_doibong);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label_muagiai);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel_themct);
            this.Name = "danhsachghiban";
            this.Text = "danhsachghiban";
            this.Load += new System.EventHandler(this.danhsachghiban_Load);
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel_themct;
        private Label label_dsgb;
        private DataGridView dataGridView1;
        private ComboBox comboBox1;
        private Label label_muagiai;
        private ComboBox comboBox_doibong;
        private Label label_doibong;
        private PictureBox pictureBox2;
    }
}