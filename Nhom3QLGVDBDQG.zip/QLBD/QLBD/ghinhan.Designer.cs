﻿namespace QLBD
{
    partial class ghinhan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_ghinhankq = new System.Windows.Forms.Label();
            this.comboBox_chonmuagiai = new System.Windows.Forms.ComboBox();
            this.label_chonmuagiai = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox_vongdau = new System.Windows.Forms.ComboBox();
            this.label_vongdau = new System.Windows.Forms.Label();
            this.label_doi2 = new System.Windows.Forms.Label();
            this.label_doi1 = new System.Windows.Forms.Label();
            this.label_tiso = new System.Windows.Forms.Label();
            this.textBox_btdoi1 = new System.Windows.Forms.TextBox();
            this.textBox_btdoi2 = new System.Windows.Forms.TextBox();
            this.label_thoiluong = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.button_sua = new System.Windows.Forms.Button();
            this.button_xoa = new System.Windows.Forms.Button();
            this.button_them = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_ghinhankq);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 15;
            // 
            // label_ghinhankq
            // 
            this.label_ghinhankq.AutoSize = true;
            this.label_ghinhankq.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_ghinhankq.ForeColor = System.Drawing.Color.White;
            this.label_ghinhankq.Location = new System.Drawing.Point(290, 9);
            this.label_ghinhankq.Name = "label_ghinhankq";
            this.label_ghinhankq.Size = new System.Drawing.Size(244, 37);
            this.label_ghinhankq.TabIndex = 0;
            this.label_ghinhankq.Text = "Ghi Nhận Kết Quả";
            // 
            // comboBox_chonmuagiai
            // 
            this.comboBox_chonmuagiai.FormattingEnabled = true;
            this.comboBox_chonmuagiai.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox_chonmuagiai.Location = new System.Drawing.Point(167, 305);
            this.comboBox_chonmuagiai.Name = "comboBox_chonmuagiai";
            this.comboBox_chonmuagiai.Size = new System.Drawing.Size(200, 28);
            this.comboBox_chonmuagiai.TabIndex = 37;
            this.comboBox_chonmuagiai.SelectedIndexChanged += new System.EventHandler(this.comboBox_chonmuagiai_SelectedIndexChanged);
            // 
            // label_chonmuagiai
            // 
            this.label_chonmuagiai.AutoSize = true;
            this.label_chonmuagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_chonmuagiai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_chonmuagiai.Location = new System.Drawing.Point(12, 305);
            this.label_chonmuagiai.Name = "label_chonmuagiai";
            this.label_chonmuagiai.Size = new System.Drawing.Size(108, 28);
            this.label_chonmuagiai.TabIndex = 36;
            this.label_chonmuagiai.Text = "Mùa Giải :";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 209);
            this.dataGridView1.TabIndex = 38;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // comboBox_vongdau
            // 
            this.comboBox_vongdau.FormattingEnabled = true;
            this.comboBox_vongdau.Items.AddRange(new object[] {
            "Vòng 1",
            "Vòng 2",
            "Vòng cuối"});
            this.comboBox_vongdau.Location = new System.Drawing.Point(621, 309);
            this.comboBox_vongdau.Name = "comboBox_vongdau";
            this.comboBox_vongdau.Size = new System.Drawing.Size(200, 28);
            this.comboBox_vongdau.TabIndex = 40;
            this.comboBox_vongdau.SelectedIndexChanged += new System.EventHandler(this.comboBox_vongdau_SelectedIndexChanged);
            // 
            // label_vongdau
            // 
            this.label_vongdau.AutoSize = true;
            this.label_vongdau.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_vongdau.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_vongdau.Location = new System.Drawing.Point(465, 309);
            this.label_vongdau.Name = "label_vongdau";
            this.label_vongdau.Size = new System.Drawing.Size(115, 28);
            this.label_vongdau.TabIndex = 39;
            this.label_vongdau.Text = "Vòng Đấu :";
            // 
            // label_doi2
            // 
            this.label_doi2.AutoSize = true;
            this.label_doi2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_doi2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_doi2.Location = new System.Drawing.Point(506, 369);
            this.label_doi2.Name = "label_doi2";
            this.label_doi2.Size = new System.Drawing.Size(74, 28);
            this.label_doi2.TabIndex = 43;
            this.label_doi2.Text = "Đội 2 :";
            // 
            // label_doi1
            // 
            this.label_doi1.AutoSize = true;
            this.label_doi1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_doi1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_doi1.Location = new System.Drawing.Point(46, 365);
            this.label_doi1.Name = "label_doi1";
            this.label_doi1.Size = new System.Drawing.Size(74, 28);
            this.label_doi1.TabIndex = 41;
            this.label_doi1.Text = "Đội 1 :";
            // 
            // label_tiso
            // 
            this.label_tiso.AutoSize = true;
            this.label_tiso.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_tiso.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_tiso.Location = new System.Drawing.Point(394, 428);
            this.label_tiso.Name = "label_tiso";
            this.label_tiso.Size = new System.Drawing.Size(64, 28);
            this.label_tiso.TabIndex = 46;
            this.label_tiso.Text = "Tỷ Số";
            this.label_tiso.Click += new System.EventHandler(this.label_tiso_Click);
            // 
            // textBox_btdoi1
            // 
            this.textBox_btdoi1.Location = new System.Drawing.Point(320, 429);
            this.textBox_btdoi1.Name = "textBox_btdoi1";
            this.textBox_btdoi1.Size = new System.Drawing.Size(68, 27);
            this.textBox_btdoi1.TabIndex = 47;
            this.textBox_btdoi1.TextChanged += new System.EventHandler(this.textBox_btdoi1_TextChanged);
            // 
            // textBox_btdoi2
            // 
            this.textBox_btdoi2.Location = new System.Drawing.Point(466, 429);
            this.textBox_btdoi2.Name = "textBox_btdoi2";
            this.textBox_btdoi2.Size = new System.Drawing.Size(68, 27);
            this.textBox_btdoi2.TabIndex = 48;
            this.textBox_btdoi2.TextChanged += new System.EventHandler(this.textBox_btdoi2_TextChanged);
            // 
            // label_thoiluong
            // 
            this.label_thoiluong.AutoSize = true;
            this.label_thoiluong.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_thoiluong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_thoiluong.Location = new System.Drawing.Point(0, 470);
            this.label_thoiluong.Name = "label_thoiluong";
            this.label_thoiluong.Size = new System.Drawing.Size(132, 28);
            this.label_thoiluong.TabIndex = 50;
            this.label_thoiluong.Text = "Thời Lượng :";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(167, 474);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(200, 27);
            this.textBox3.TabIndex = 51;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // button_sua
            // 
            this.button_sua.BackColor = System.Drawing.Color.Yellow;
            this.button_sua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_sua.ForeColor = System.Drawing.Color.White;
            this.button_sua.Location = new System.Drawing.Point(584, 507);
            this.button_sua.Name = "button_sua";
            this.button_sua.Size = new System.Drawing.Size(94, 37);
            this.button_sua.TabIndex = 54;
            this.button_sua.Text = "Sửa";
            this.button_sua.UseVisualStyleBackColor = false;
            // 
            // button_xoa
            // 
            this.button_xoa.BackColor = System.Drawing.Color.Red;
            this.button_xoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_xoa.ForeColor = System.Drawing.Color.White;
            this.button_xoa.Location = new System.Drawing.Point(727, 507);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(94, 37);
            this.button_xoa.TabIndex = 53;
            this.button_xoa.Text = "Xóa";
            this.button_xoa.UseVisualStyleBackColor = false;
            // 
            // button_them
            // 
            this.button_them.BackColor = System.Drawing.Color.Green;
            this.button_them.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_them.ForeColor = System.Drawing.Color.White;
            this.button_them.Location = new System.Drawing.Point(440, 507);
            this.button_them.Name = "button_them";
            this.button_them.Size = new System.Drawing.Size(94, 37);
            this.button_them.TabIndex = 52;
            this.button_them.Text = "Thêm";
            this.button_them.UseVisualStyleBackColor = false;
            this.button_them.Click += new System.EventHandler(this.button_them_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(7, 501);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(113, 46);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 55;
            this.pictureBox2.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(167, 370);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 28);
            this.comboBox1.TabIndex = 56;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(621, 377);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(200, 28);
            this.comboBox2.TabIndex = 57;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // ghinhan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_sua);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_them);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label_thoiluong);
            this.Controls.Add(this.textBox_btdoi2);
            this.Controls.Add(this.textBox_btdoi1);
            this.Controls.Add(this.label_tiso);
            this.Controls.Add(this.label_doi2);
            this.Controls.Add(this.label_doi1);
            this.Controls.Add(this.comboBox_vongdau);
            this.Controls.Add(this.label_vongdau);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.comboBox_chonmuagiai);
            this.Controls.Add(this.label_chonmuagiai);
            this.Controls.Add(this.panel_themct);
            this.Name = "ghinhan";
            this.Text = "ghinhan";
            this.Load += new System.EventHandler(this.ghinhan_Load);
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel_themct;
        private Label label_ghinhankq;
        private ComboBox comboBox_chonmuagiai;
        private Label label_chonmuagiai;
        private DataGridView dataGridView1;
        private ComboBox comboBox_vongdau;
        private Label label_vongdau;
        private Label label_doi2;
        private Label label_doi1;
        private Label label_tiso;
        private TextBox textBox_btdoi1;
        private TextBox textBox_btdoi2;
        private Label label_thoiluong;
        private TextBox textBox3;
        private Button button_sua;
        private Button button_xoa;
        private Button button_them;
        private PictureBox pictureBox2;
        private ComboBox comboBox1;
        private ComboBox comboBox2;
    }
}