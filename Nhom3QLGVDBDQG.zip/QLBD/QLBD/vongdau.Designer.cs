﻿namespace QLBD
{
    partial class vongdau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_dsgb = new System.Windows.Forms.Label();
            this.textBox_tenvd = new System.Windows.Forms.TextBox();
            this.label_tdghibantoida = new System.Windows.Forms.Label();
            this.comboBox_chonmuagiai = new System.Windows.Forms.ComboBox();
            this.label_chonmuagiai = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button_sua = new System.Windows.Forms.Button();
            this.button_them = new System.Windows.Forms.Button();
            this.button_xoa = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 192);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_dsgb);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 19;
            // 
            // label_dsgb
            // 
            this.label_dsgb.AutoSize = true;
            this.label_dsgb.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_dsgb.ForeColor = System.Drawing.Color.White;
            this.label_dsgb.Location = new System.Drawing.Point(355, 9);
            this.label_dsgb.Name = "label_dsgb";
            this.label_dsgb.Size = new System.Drawing.Size(141, 37);
            this.label_dsgb.TabIndex = 0;
            this.label_dsgb.Text = "Vòng Đấu";
            // 
            // textBox_tenvd
            // 
            this.textBox_tenvd.Location = new System.Drawing.Point(190, 333);
            this.textBox_tenvd.Name = "textBox_tenvd";
            this.textBox_tenvd.Size = new System.Drawing.Size(200, 27);
            this.textBox_tenvd.TabIndex = 36;
            this.textBox_tenvd.TextChanged += new System.EventHandler(this.textBox_tenvd_TextChanged);
            // 
            // label_tdghibantoida
            // 
            this.label_tdghibantoida.AutoSize = true;
            this.label_tdghibantoida.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_tdghibantoida.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_tdghibantoida.Location = new System.Drawing.Point(12, 329);
            this.label_tdghibantoida.Name = "label_tdghibantoida";
            this.label_tdghibantoida.Size = new System.Drawing.Size(154, 28);
            this.label_tdghibantoida.TabIndex = 35;
            this.label_tdghibantoida.Text = "Tên Vòng Đấu :";
            // 
            // comboBox_chonmuagiai
            // 
            this.comboBox_chonmuagiai.FormattingEnabled = true;
            this.comboBox_chonmuagiai.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox_chonmuagiai.Location = new System.Drawing.Point(639, 329);
            this.comboBox_chonmuagiai.Name = "comboBox_chonmuagiai";
            this.comboBox_chonmuagiai.Size = new System.Drawing.Size(200, 28);
            this.comboBox_chonmuagiai.TabIndex = 38;
            this.comboBox_chonmuagiai.SelectedIndexChanged += new System.EventHandler(this.comboBox_chonmuagiai_SelectedIndexChanged);
            // 
            // label_chonmuagiai
            // 
            this.label_chonmuagiai.AutoSize = true;
            this.label_chonmuagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_chonmuagiai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_chonmuagiai.Location = new System.Drawing.Point(509, 329);
            this.label_chonmuagiai.Name = "label_chonmuagiai";
            this.label_chonmuagiai.Size = new System.Drawing.Size(108, 28);
            this.label_chonmuagiai.TabIndex = 37;
            this.label_chonmuagiai.Text = "Mùa Giải :";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(0, 494);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 49;
            this.pictureBox2.TabStop = false;
            // 
            // button_sua
            // 
            this.button_sua.BackColor = System.Drawing.Color.Yellow;
            this.button_sua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_sua.ForeColor = System.Drawing.Color.White;
            this.button_sua.Location = new System.Drawing.Point(523, 494);
            this.button_sua.Name = "button_sua";
            this.button_sua.Size = new System.Drawing.Size(94, 37);
            this.button_sua.TabIndex = 47;
            this.button_sua.Text = "Sửa";
            this.button_sua.UseVisualStyleBackColor = false;
            // 
            // button_them
            // 
            this.button_them.BackColor = System.Drawing.Color.Green;
            this.button_them.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_them.ForeColor = System.Drawing.Color.White;
            this.button_them.Location = new System.Drawing.Point(361, 494);
            this.button_them.Name = "button_them";
            this.button_them.Size = new System.Drawing.Size(94, 37);
            this.button_them.TabIndex = 46;
            this.button_them.Text = "Thêm";
            this.button_them.UseVisualStyleBackColor = false;
            this.button_them.Click += new System.EventHandler(this.button_them_Click);
            // 
            // button_xoa
            // 
            this.button_xoa.BackColor = System.Drawing.Color.Red;
            this.button_xoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_xoa.ForeColor = System.Drawing.Color.White;
            this.button_xoa.Location = new System.Drawing.Point(675, 494);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(94, 37);
            this.button_xoa.TabIndex = 48;
            this.button_xoa.Text = "Xóa";
            this.button_xoa.UseVisualStyleBackColor = false;
            // 
            // vongdau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_sua);
            this.Controls.Add(this.button_them);
            this.Controls.Add(this.comboBox_chonmuagiai);
            this.Controls.Add(this.label_chonmuagiai);
            this.Controls.Add(this.textBox_tenvd);
            this.Controls.Add(this.label_tdghibantoida);
            this.Controls.Add(this.panel_themct);
            this.Controls.Add(this.dataGridView1);
            this.MinimumSize = new System.Drawing.Size(874, 603);
            this.Name = "vongdau";
            this.Text = "vongdau";
            this.Load += new System.EventHandler(this.vongdau_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataGridView dataGridView1;
        private Panel panel_themct;
        private Label label_dsgb;
        private TextBox textBox_tenvd;
        private Label label_tdghibantoida;
        private ComboBox comboBox_chonmuagiai;
        private Label label_chonmuagiai;
        private PictureBox pictureBox2;
        private Button button_sua;
        private Button button_them;
        private Button button_xoa;
    }
}