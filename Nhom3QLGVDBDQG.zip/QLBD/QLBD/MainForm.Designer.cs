﻿namespace QLBD
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.panel_slide = new System.Windows.Forms.Panel();
            this.panel_qdsubmenu = new System.Windows.Forms.Panel();
            this.button_quaylai = new System.Windows.Forms.Button();
            this.button_muagiai = new System.Windows.Forms.Button();
            this.button_vongdau = new System.Windows.Forms.Button();
            this.button_qdloaicauthu = new System.Windows.Forms.Button();
            this.button_qdbanthang = new System.Windows.Forms.Button();
            this.button_quydinhct = new System.Windows.Forms.Button();
            this.button_quydinh = new System.Windows.Forms.Button();
            this.panel_tbsubmenu = new System.Windows.Forms.Panel();
            this.button_backtrabao = new System.Windows.Forms.Button();
            this.button_timkiem = new System.Windows.Forms.Button();
            this.button_dsghiban = new System.Windows.Forms.Button();
            this.button_bangxh = new System.Windows.Forms.Button();
            this.button_trabao = new System.Windows.Forms.Button();
            this.panel_kqsubmenu = new System.Windows.Forms.Panel();
            this.button_backkq = new System.Windows.Forms.Button();
            this.button_xemkq = new System.Windows.Forms.Button();
            this.button_themct = new System.Windows.Forms.Button();
            this.button_ghinhan = new System.Windows.Forms.Button();
            this.button_kqthidau = new System.Windows.Forms.Button();
            this.panel_ltdsubmenu = new System.Windows.Forms.Panel();
            this.button_backltd = new System.Windows.Forms.Button();
            this.button_xemlichtd = new System.Windows.Forms.Button();
            this.button_laplichtd = new System.Windows.Forms.Button();
            this.button_lichthidau = new System.Windows.Forms.Button();
            this.panel_qlgsubmenu = new System.Windows.Forms.Panel();
            this.button_backqlg = new System.Windows.Forms.Button();
            this.button_thongtindoi = new System.Windows.Forms.Button();
            this.button_themcauthu = new System.Windows.Forms.Button();
            this.button_quanlidoi = new System.Windows.Forms.Button();
            this.button_qlg = new System.Windows.Forms.Button();
            this.panel_logo = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel_main = new System.Windows.Forms.Panel();
            this.panel_cover = new System.Windows.Forms.Panel();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel_slide.SuspendLayout();
            this.panel_qdsubmenu.SuspendLayout();
            this.panel_tbsubmenu.SuspendLayout();
            this.panel_kqsubmenu.SuspendLayout();
            this.panel_ltdsubmenu.SuspendLayout();
            this.panel_qlgsubmenu.SuspendLayout();
            this.panel_logo.SuspendLayout();
            this.panel_main.SuspendLayout();
            this.panel_cover.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_slide
            // 
            this.panel_slide.AutoScroll = true;
            this.panel_slide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_slide.Controls.Add(this.panel_qdsubmenu);
            this.panel_slide.Controls.Add(this.button_quydinh);
            this.panel_slide.Controls.Add(this.panel_tbsubmenu);
            this.panel_slide.Controls.Add(this.button_trabao);
            this.panel_slide.Controls.Add(this.panel_kqsubmenu);
            this.panel_slide.Controls.Add(this.button_kqthidau);
            this.panel_slide.Controls.Add(this.panel_ltdsubmenu);
            this.panel_slide.Controls.Add(this.button_lichthidau);
            this.panel_slide.Controls.Add(this.panel_qlgsubmenu);
            this.panel_slide.Controls.Add(this.button_qlg);
            this.panel_slide.Controls.Add(this.panel_logo);
            this.panel_slide.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_slide.Location = new System.Drawing.Point(0, 0);
            this.panel_slide.Name = "panel_slide";
            this.panel_slide.Size = new System.Drawing.Size(258, 603);
            this.panel_slide.TabIndex = 0;
            // 
            // panel_qdsubmenu
            // 
            this.panel_qdsubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(200)))));
            this.panel_qdsubmenu.Controls.Add(this.button_quaylai);
            this.panel_qdsubmenu.Controls.Add(this.button_muagiai);
            this.panel_qdsubmenu.Controls.Add(this.button_vongdau);
            this.panel_qdsubmenu.Controls.Add(this.button_qdloaicauthu);
            this.panel_qdsubmenu.Controls.Add(this.button_qdbanthang);
            this.panel_qdsubmenu.Controls.Add(this.button_quydinhct);
            this.panel_qdsubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_qdsubmenu.Location = new System.Drawing.Point(0, 1021);
            this.panel_qdsubmenu.Name = "panel_qdsubmenu";
            this.panel_qdsubmenu.Size = new System.Drawing.Size(237, 270);
            this.panel_qdsubmenu.TabIndex = 10;
            // 
            // button_quaylai
            // 
            this.button_quaylai.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_quaylai.FlatAppearance.BorderSize = 0;
            this.button_quaylai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_quaylai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_quaylai.ForeColor = System.Drawing.Color.White;
            this.button_quaylai.Location = new System.Drawing.Point(0, 225);
            this.button_quaylai.Name = "button_quaylai";
            this.button_quaylai.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_quaylai.Size = new System.Drawing.Size(237, 45);
            this.button_quaylai.TabIndex = 5;
            this.button_quaylai.Text = "Quay Lại";
            this.button_quaylai.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_quaylai.UseVisualStyleBackColor = true;
            this.button_quaylai.Click += new System.EventHandler(this.button_quaylai_Click);
            // 
            // button_muagiai
            // 
            this.button_muagiai.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_muagiai.FlatAppearance.BorderSize = 0;
            this.button_muagiai.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_muagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_muagiai.ForeColor = System.Drawing.Color.White;
            this.button_muagiai.Location = new System.Drawing.Point(0, 180);
            this.button_muagiai.Name = "button_muagiai";
            this.button_muagiai.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_muagiai.Size = new System.Drawing.Size(237, 45);
            this.button_muagiai.TabIndex = 4;
            this.button_muagiai.Text = "Mùa Giải";
            this.button_muagiai.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_muagiai.UseVisualStyleBackColor = true;
            this.button_muagiai.Click += new System.EventHandler(this.button_muagiai_Click);
            // 
            // button_vongdau
            // 
            this.button_vongdau.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_vongdau.FlatAppearance.BorderSize = 0;
            this.button_vongdau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_vongdau.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_vongdau.ForeColor = System.Drawing.Color.White;
            this.button_vongdau.Location = new System.Drawing.Point(0, 135);
            this.button_vongdau.Name = "button_vongdau";
            this.button_vongdau.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_vongdau.Size = new System.Drawing.Size(237, 45);
            this.button_vongdau.TabIndex = 3;
            this.button_vongdau.Text = "Vòng Đấu";
            this.button_vongdau.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_vongdau.UseVisualStyleBackColor = true;
            this.button_vongdau.Click += new System.EventHandler(this.button_vongdau_Click);
            // 
            // button_qdloaicauthu
            // 
            this.button_qdloaicauthu.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_qdloaicauthu.FlatAppearance.BorderSize = 0;
            this.button_qdloaicauthu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_qdloaicauthu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_qdloaicauthu.ForeColor = System.Drawing.Color.White;
            this.button_qdloaicauthu.Location = new System.Drawing.Point(0, 90);
            this.button_qdloaicauthu.Name = "button_qdloaicauthu";
            this.button_qdloaicauthu.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_qdloaicauthu.Size = new System.Drawing.Size(237, 45);
            this.button_qdloaicauthu.TabIndex = 2;
            this.button_qdloaicauthu.Text = "Loại Cầu Thủ";
            this.button_qdloaicauthu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_qdloaicauthu.UseVisualStyleBackColor = true;
            this.button_qdloaicauthu.Click += new System.EventHandler(this.button_qdloaicauthu_Click);
            // 
            // button_qdbanthang
            // 
            this.button_qdbanthang.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_qdbanthang.FlatAppearance.BorderSize = 0;
            this.button_qdbanthang.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_qdbanthang.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_qdbanthang.ForeColor = System.Drawing.Color.White;
            this.button_qdbanthang.Location = new System.Drawing.Point(0, 45);
            this.button_qdbanthang.Name = "button_qdbanthang";
            this.button_qdbanthang.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_qdbanthang.Size = new System.Drawing.Size(237, 45);
            this.button_qdbanthang.TabIndex = 1;
            this.button_qdbanthang.Text = "Quy Định Bàn Thắng";
            this.button_qdbanthang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_qdbanthang.UseVisualStyleBackColor = true;
            this.button_qdbanthang.Click += new System.EventHandler(this.button_qdbanthang_Click);
            // 
            // button_quydinhct
            // 
            this.button_quydinhct.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_quydinhct.FlatAppearance.BorderSize = 0;
            this.button_quydinhct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_quydinhct.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_quydinhct.ForeColor = System.Drawing.Color.White;
            this.button_quydinhct.Location = new System.Drawing.Point(0, 0);
            this.button_quydinhct.Name = "button_quydinhct";
            this.button_quydinhct.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_quydinhct.Size = new System.Drawing.Size(237, 45);
            this.button_quydinhct.TabIndex = 0;
            this.button_quydinhct.Text = "Quy Định Cầu Thủ";
            this.button_quydinhct.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_quydinhct.UseVisualStyleBackColor = true;
            this.button_quydinhct.Click += new System.EventHandler(this.button_quydinhct_Click);
            // 
            // button_quydinh
            // 
            this.button_quydinh.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_quydinh.FlatAppearance.BorderSize = 0;
            this.button_quydinh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_quydinh.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_quydinh.ForeColor = System.Drawing.Color.White;
            this.button_quydinh.Location = new System.Drawing.Point(0, 976);
            this.button_quydinh.Name = "button_quydinh";
            this.button_quydinh.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button_quydinh.Size = new System.Drawing.Size(237, 45);
            this.button_quydinh.TabIndex = 9;
            this.button_quydinh.Text = "Quy Định";
            this.button_quydinh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_quydinh.UseVisualStyleBackColor = true;
            this.button_quydinh.Click += new System.EventHandler(this.button_quydinh_Click);
            // 
            // panel_tbsubmenu
            // 
            this.panel_tbsubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(200)))));
            this.panel_tbsubmenu.Controls.Add(this.button_backtrabao);
            this.panel_tbsubmenu.Controls.Add(this.button_timkiem);
            this.panel_tbsubmenu.Controls.Add(this.button_dsghiban);
            this.panel_tbsubmenu.Controls.Add(this.button_bangxh);
            this.panel_tbsubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_tbsubmenu.Location = new System.Drawing.Point(0, 796);
            this.panel_tbsubmenu.Name = "panel_tbsubmenu";
            this.panel_tbsubmenu.Size = new System.Drawing.Size(237, 180);
            this.panel_tbsubmenu.TabIndex = 8;
            // 
            // button_backtrabao
            // 
            this.button_backtrabao.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_backtrabao.FlatAppearance.BorderSize = 0;
            this.button_backtrabao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_backtrabao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_backtrabao.ForeColor = System.Drawing.Color.White;
            this.button_backtrabao.Location = new System.Drawing.Point(0, 135);
            this.button_backtrabao.Name = "button_backtrabao";
            this.button_backtrabao.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_backtrabao.Size = new System.Drawing.Size(237, 45);
            this.button_backtrabao.TabIndex = 6;
            this.button_backtrabao.Text = "Quay Lại";
            this.button_backtrabao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_backtrabao.UseVisualStyleBackColor = true;
            this.button_backtrabao.Click += new System.EventHandler(this.button_backtrabao_Click);
            // 
            // button_timkiem
            // 
            this.button_timkiem.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_timkiem.FlatAppearance.BorderSize = 0;
            this.button_timkiem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_timkiem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_timkiem.ForeColor = System.Drawing.Color.White;
            this.button_timkiem.Location = new System.Drawing.Point(0, 90);
            this.button_timkiem.Name = "button_timkiem";
            this.button_timkiem.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_timkiem.Size = new System.Drawing.Size(237, 45);
            this.button_timkiem.TabIndex = 2;
            this.button_timkiem.Text = "Tìm Kiếm";
            this.button_timkiem.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_timkiem.UseVisualStyleBackColor = true;
            this.button_timkiem.Click += new System.EventHandler(this.button_timkiem_Click);
            // 
            // button_dsghiban
            // 
            this.button_dsghiban.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_dsghiban.FlatAppearance.BorderSize = 0;
            this.button_dsghiban.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_dsghiban.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_dsghiban.ForeColor = System.Drawing.Color.White;
            this.button_dsghiban.Location = new System.Drawing.Point(0, 45);
            this.button_dsghiban.Name = "button_dsghiban";
            this.button_dsghiban.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_dsghiban.Size = new System.Drawing.Size(237, 45);
            this.button_dsghiban.TabIndex = 1;
            this.button_dsghiban.Text = "Danh Sách Ghi Bàn";
            this.button_dsghiban.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_dsghiban.UseVisualStyleBackColor = true;
            this.button_dsghiban.Click += new System.EventHandler(this.button_dsghiban_Click);
            // 
            // button_bangxh
            // 
            this.button_bangxh.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_bangxh.FlatAppearance.BorderSize = 0;
            this.button_bangxh.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_bangxh.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_bangxh.ForeColor = System.Drawing.Color.White;
            this.button_bangxh.Location = new System.Drawing.Point(0, 0);
            this.button_bangxh.Name = "button_bangxh";
            this.button_bangxh.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_bangxh.Size = new System.Drawing.Size(237, 45);
            this.button_bangxh.TabIndex = 0;
            this.button_bangxh.Text = "Bảng Xếp Hạng";
            this.button_bangxh.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_bangxh.UseVisualStyleBackColor = true;
            this.button_bangxh.Click += new System.EventHandler(this.button_bangxh_Click);
            // 
            // button_trabao
            // 
            this.button_trabao.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_trabao.FlatAppearance.BorderSize = 0;
            this.button_trabao.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_trabao.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_trabao.ForeColor = System.Drawing.Color.White;
            this.button_trabao.Location = new System.Drawing.Point(0, 751);
            this.button_trabao.Name = "button_trabao";
            this.button_trabao.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button_trabao.Size = new System.Drawing.Size(237, 45);
            this.button_trabao.TabIndex = 7;
            this.button_trabao.Text = "Tra Cứu, Báo Cáo";
            this.button_trabao.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_trabao.UseVisualStyleBackColor = true;
            this.button_trabao.Click += new System.EventHandler(this.button_trabao_Click);
            // 
            // panel_kqsubmenu
            // 
            this.panel_kqsubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(200)))));
            this.panel_kqsubmenu.Controls.Add(this.button_backkq);
            this.panel_kqsubmenu.Controls.Add(this.button_xemkq);
            this.panel_kqsubmenu.Controls.Add(this.button_themct);
            this.panel_kqsubmenu.Controls.Add(this.button_ghinhan);
            this.panel_kqsubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_kqsubmenu.Location = new System.Drawing.Point(0, 571);
            this.panel_kqsubmenu.Name = "panel_kqsubmenu";
            this.panel_kqsubmenu.Size = new System.Drawing.Size(237, 180);
            this.panel_kqsubmenu.TabIndex = 6;
            // 
            // button_backkq
            // 
            this.button_backkq.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_backkq.FlatAppearance.BorderSize = 0;
            this.button_backkq.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_backkq.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_backkq.ForeColor = System.Drawing.Color.White;
            this.button_backkq.Location = new System.Drawing.Point(0, 135);
            this.button_backkq.Name = "button_backkq";
            this.button_backkq.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_backkq.Size = new System.Drawing.Size(237, 45);
            this.button_backkq.TabIndex = 6;
            this.button_backkq.Text = "Quay Lại";
            this.button_backkq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_backkq.UseVisualStyleBackColor = true;
            this.button_backkq.Click += new System.EventHandler(this.button_backkq_Click);
            // 
            // button_xemkq
            // 
            this.button_xemkq.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_xemkq.FlatAppearance.BorderSize = 0;
            this.button_xemkq.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_xemkq.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_xemkq.ForeColor = System.Drawing.Color.White;
            this.button_xemkq.Location = new System.Drawing.Point(0, 90);
            this.button_xemkq.Name = "button_xemkq";
            this.button_xemkq.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_xemkq.Size = new System.Drawing.Size(237, 45);
            this.button_xemkq.TabIndex = 2;
            this.button_xemkq.Text = "Xem Kết Quả";
            this.button_xemkq.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_xemkq.UseVisualStyleBackColor = true;
            this.button_xemkq.Click += new System.EventHandler(this.button_xemkq_Click);
            // 
            // button_themct
            // 
            this.button_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_themct.FlatAppearance.BorderSize = 0;
            this.button_themct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_themct.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_themct.ForeColor = System.Drawing.Color.White;
            this.button_themct.Location = new System.Drawing.Point(0, 45);
            this.button_themct.Name = "button_themct";
            this.button_themct.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_themct.Size = new System.Drawing.Size(237, 45);
            this.button_themct.TabIndex = 1;
            this.button_themct.Text = "Thêm Cầu Thủ";
            this.button_themct.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_themct.UseVisualStyleBackColor = true;
            this.button_themct.Click += new System.EventHandler(this.button_themct_Click);
            // 
            // button_ghinhan
            // 
            this.button_ghinhan.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_ghinhan.FlatAppearance.BorderSize = 0;
            this.button_ghinhan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_ghinhan.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_ghinhan.ForeColor = System.Drawing.Color.White;
            this.button_ghinhan.Location = new System.Drawing.Point(0, 0);
            this.button_ghinhan.Name = "button_ghinhan";
            this.button_ghinhan.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_ghinhan.Size = new System.Drawing.Size(237, 45);
            this.button_ghinhan.TabIndex = 0;
            this.button_ghinhan.Text = "Ghi Nhận";
            this.button_ghinhan.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_ghinhan.UseVisualStyleBackColor = true;
            this.button_ghinhan.Click += new System.EventHandler(this.button_ghinhan_Click);
            // 
            // button_kqthidau
            // 
            this.button_kqthidau.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_kqthidau.FlatAppearance.BorderSize = 0;
            this.button_kqthidau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_kqthidau.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_kqthidau.ForeColor = System.Drawing.Color.White;
            this.button_kqthidau.Location = new System.Drawing.Point(0, 526);
            this.button_kqthidau.Name = "button_kqthidau";
            this.button_kqthidau.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button_kqthidau.Size = new System.Drawing.Size(237, 45);
            this.button_kqthidau.TabIndex = 5;
            this.button_kqthidau.Text = "Kết Quả Thi Đấu";
            this.button_kqthidau.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_kqthidau.UseVisualStyleBackColor = true;
            this.button_kqthidau.Click += new System.EventHandler(this.button_kqthidau_Click);
            // 
            // panel_ltdsubmenu
            // 
            this.panel_ltdsubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(200)))));
            this.panel_ltdsubmenu.Controls.Add(this.button_backltd);
            this.panel_ltdsubmenu.Controls.Add(this.button_xemlichtd);
            this.panel_ltdsubmenu.Controls.Add(this.button_laplichtd);
            this.panel_ltdsubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_ltdsubmenu.Location = new System.Drawing.Point(0, 391);
            this.panel_ltdsubmenu.Name = "panel_ltdsubmenu";
            this.panel_ltdsubmenu.Size = new System.Drawing.Size(237, 135);
            this.panel_ltdsubmenu.TabIndex = 4;
            // 
            // button_backltd
            // 
            this.button_backltd.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_backltd.FlatAppearance.BorderSize = 0;
            this.button_backltd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_backltd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_backltd.ForeColor = System.Drawing.Color.White;
            this.button_backltd.Location = new System.Drawing.Point(0, 90);
            this.button_backltd.Name = "button_backltd";
            this.button_backltd.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_backltd.Size = new System.Drawing.Size(237, 45);
            this.button_backltd.TabIndex = 6;
            this.button_backltd.Text = "Quay Lại";
            this.button_backltd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_backltd.UseVisualStyleBackColor = true;
            this.button_backltd.Click += new System.EventHandler(this.button_backltd_Click);
            // 
            // button_xemlichtd
            // 
            this.button_xemlichtd.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_xemlichtd.FlatAppearance.BorderSize = 0;
            this.button_xemlichtd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_xemlichtd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_xemlichtd.ForeColor = System.Drawing.Color.White;
            this.button_xemlichtd.Location = new System.Drawing.Point(0, 45);
            this.button_xemlichtd.Name = "button_xemlichtd";
            this.button_xemlichtd.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_xemlichtd.Size = new System.Drawing.Size(237, 45);
            this.button_xemlichtd.TabIndex = 1;
            this.button_xemlichtd.Text = "Xem Lịch Thi Đấu";
            this.button_xemlichtd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_xemlichtd.UseVisualStyleBackColor = true;
            this.button_xemlichtd.Click += new System.EventHandler(this.button_xemlichtd_Click);
            // 
            // button_laplichtd
            // 
            this.button_laplichtd.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_laplichtd.FlatAppearance.BorderSize = 0;
            this.button_laplichtd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_laplichtd.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_laplichtd.ForeColor = System.Drawing.Color.White;
            this.button_laplichtd.Location = new System.Drawing.Point(0, 0);
            this.button_laplichtd.Name = "button_laplichtd";
            this.button_laplichtd.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_laplichtd.Size = new System.Drawing.Size(237, 45);
            this.button_laplichtd.TabIndex = 0;
            this.button_laplichtd.Text = "Lập Lịch Thi Đấu";
            this.button_laplichtd.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_laplichtd.UseVisualStyleBackColor = true;
            this.button_laplichtd.Click += new System.EventHandler(this.button_laplichtd_Click);
            // 
            // button_lichthidau
            // 
            this.button_lichthidau.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_lichthidau.FlatAppearance.BorderSize = 0;
            this.button_lichthidau.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_lichthidau.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_lichthidau.ForeColor = System.Drawing.Color.White;
            this.button_lichthidau.Location = new System.Drawing.Point(0, 346);
            this.button_lichthidau.Name = "button_lichthidau";
            this.button_lichthidau.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button_lichthidau.Size = new System.Drawing.Size(237, 45);
            this.button_lichthidau.TabIndex = 3;
            this.button_lichthidau.Text = "Lịch Thi Đấu";
            this.button_lichthidau.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_lichthidau.UseVisualStyleBackColor = true;
            this.button_lichthidau.Click += new System.EventHandler(this.button_lichthidau_Click);
            // 
            // panel_qlgsubmenu
            // 
            this.panel_qlgsubmenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(200)))));
            this.panel_qlgsubmenu.Controls.Add(this.button_backqlg);
            this.panel_qlgsubmenu.Controls.Add(this.button_thongtindoi);
            this.panel_qlgsubmenu.Controls.Add(this.button_themcauthu);
            this.panel_qlgsubmenu.Controls.Add(this.button_quanlidoi);
            this.panel_qlgsubmenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_qlgsubmenu.Location = new System.Drawing.Point(0, 166);
            this.panel_qlgsubmenu.Name = "panel_qlgsubmenu";
            this.panel_qlgsubmenu.Size = new System.Drawing.Size(237, 180);
            this.panel_qlgsubmenu.TabIndex = 2;
            this.panel_qlgsubmenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // button_backqlg
            // 
            this.button_backqlg.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_backqlg.FlatAppearance.BorderSize = 0;
            this.button_backqlg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_backqlg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_backqlg.ForeColor = System.Drawing.Color.White;
            this.button_backqlg.Location = new System.Drawing.Point(0, 135);
            this.button_backqlg.Name = "button_backqlg";
            this.button_backqlg.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_backqlg.Size = new System.Drawing.Size(237, 45);
            this.button_backqlg.TabIndex = 6;
            this.button_backqlg.Text = "Quay Lại";
            this.button_backqlg.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_backqlg.UseVisualStyleBackColor = true;
            this.button_backqlg.Click += new System.EventHandler(this.button_backqlg_Click);
            // 
            // button_thongtindoi
            // 
            this.button_thongtindoi.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_thongtindoi.FlatAppearance.BorderSize = 0;
            this.button_thongtindoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_thongtindoi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_thongtindoi.ForeColor = System.Drawing.Color.White;
            this.button_thongtindoi.Location = new System.Drawing.Point(0, 90);
            this.button_thongtindoi.Name = "button_thongtindoi";
            this.button_thongtindoi.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_thongtindoi.Size = new System.Drawing.Size(237, 45);
            this.button_thongtindoi.TabIndex = 2;
            this.button_thongtindoi.Text = "Thông Tin Đội";
            this.button_thongtindoi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_thongtindoi.UseVisualStyleBackColor = true;
            this.button_thongtindoi.Click += new System.EventHandler(this.button_thongtindoi_Click);
            // 
            // button_themcauthu
            // 
            this.button_themcauthu.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_themcauthu.FlatAppearance.BorderSize = 0;
            this.button_themcauthu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_themcauthu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_themcauthu.ForeColor = System.Drawing.Color.White;
            this.button_themcauthu.Location = new System.Drawing.Point(0, 45);
            this.button_themcauthu.Name = "button_themcauthu";
            this.button_themcauthu.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_themcauthu.Size = new System.Drawing.Size(237, 45);
            this.button_themcauthu.TabIndex = 1;
            this.button_themcauthu.Text = "Thêm Cầu Thủ";
            this.button_themcauthu.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_themcauthu.UseVisualStyleBackColor = true;
            this.button_themcauthu.Click += new System.EventHandler(this.button2_Click);
            // 
            // button_quanlidoi
            // 
            this.button_quanlidoi.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_quanlidoi.FlatAppearance.BorderSize = 0;
            this.button_quanlidoi.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_quanlidoi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_quanlidoi.ForeColor = System.Drawing.Color.White;
            this.button_quanlidoi.Location = new System.Drawing.Point(0, 0);
            this.button_quanlidoi.Name = "button_quanlidoi";
            this.button_quanlidoi.Padding = new System.Windows.Forms.Padding(35, 0, 0, 0);
            this.button_quanlidoi.Size = new System.Drawing.Size(237, 45);
            this.button_quanlidoi.TabIndex = 0;
            this.button_quanlidoi.Text = "Đăng Ký Đội";
            this.button_quanlidoi.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_quanlidoi.UseVisualStyleBackColor = true;
            this.button_quanlidoi.Click += new System.EventHandler(this.button_quanlidoi_Click);
            // 
            // button_qlg
            // 
            this.button_qlg.Dock = System.Windows.Forms.DockStyle.Top;
            this.button_qlg.FlatAppearance.BorderSize = 0;
            this.button_qlg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button_qlg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.button_qlg.ForeColor = System.Drawing.Color.White;
            this.button_qlg.Location = new System.Drawing.Point(0, 121);
            this.button_qlg.Name = "button_qlg";
            this.button_qlg.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.button_qlg.Size = new System.Drawing.Size(237, 45);
            this.button_qlg.TabIndex = 1;
            this.button_qlg.Text = "Quản Lý Giải";
            this.button_qlg.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button_qlg.UseVisualStyleBackColor = true;
            this.button_qlg.Click += new System.EventHandler(this.button_qlg_Click);
            // 
            // panel_logo
            // 
            this.panel_logo.Controls.Add(this.label4);
            this.panel_logo.Controls.Add(this.label3);
            this.panel_logo.Controls.Add(this.label2);
            this.panel_logo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_logo.Location = new System.Drawing.Point(0, 0);
            this.panel_logo.Name = "panel_logo";
            this.panel_logo.Size = new System.Drawing.Size(237, 121);
            this.panel_logo.TabIndex = 0;
            this.panel_logo.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_logo_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(132, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 22);
            this.label4.TabIndex = 3;
            this.label4.Text = "V-League";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Britannic Bold", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(12, 75);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 22);
            this.label3.TabIndex = 2;
            this.label3.Text = "Welcome To";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Broadway", 36F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(78, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 68);
            this.label2.TabIndex = 1;
            this.label2.Text = "V";
            // 
            // panel_main
            // 
            this.panel_main.BackColor = System.Drawing.Color.White;
            this.panel_main.Controls.Add(this.panel_cover);
            this.panel_main.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_main.Location = new System.Drawing.Point(258, 0);
            this.panel_main.Name = "panel_main";
            this.panel_main.Size = new System.Drawing.Size(874, 603);
            this.panel_main.TabIndex = 1;
            // 
            // panel_cover
            // 
            this.panel_cover.Controls.Add(this.pictureBox3);
            this.panel_cover.Controls.Add(this.panel3);
            this.panel_cover.Controls.Add(this.panel2);
            this.panel_cover.Controls.Add(this.panel1);
            this.panel_cover.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_cover.Location = new System.Drawing.Point(0, 0);
            this.panel_cover.Name = "panel_cover";
            this.panel_cover.Size = new System.Drawing.Size(874, 603);
            this.panel_cover.TabIndex = 0;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 176);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(874, 330);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel3.Location = new System.Drawing.Point(0, 506);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(874, 97);
            this.panel3.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(6, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(305, 28);
            this.label7.TabIndex = 1;
            this.label7.Text = "Football League Mangagement";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(721, 21);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 87);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(874, 89);
            this.panel2.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.pictureBox1.Image = global::QLBD.Properties.Resources.ball;
            this.pictureBox1.Location = new System.Drawing.Point(721, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(125, 70);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(90, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(133, 28);
            this.label5.TabIndex = 1;
            this.label5.Text = "Role : Admin";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(46, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 28);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome : V-League ";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(874, 87);
            this.panel1.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label6.Location = new System.Drawing.Point(28, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(347, 38);
            this.label6.TabIndex = 1;
            this.label6.Text = "National Football League";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1132, 603);
            this.Controls.Add(this.panel_main);
            this.Controls.Add(this.panel_slide);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.MinimumSize = new System.Drawing.Size(1150, 650);
            this.Name = "MainForm";
            this.Text = "Quản lí giải đá bóng vô địch Quốc gia";
            this.panel_slide.ResumeLayout(false);
            this.panel_qdsubmenu.ResumeLayout(false);
            this.panel_tbsubmenu.ResumeLayout(false);
            this.panel_kqsubmenu.ResumeLayout(false);
            this.panel_ltdsubmenu.ResumeLayout(false);
            this.panel_qlgsubmenu.ResumeLayout(false);
            this.panel_logo.ResumeLayout(false);
            this.panel_logo.PerformLayout();
            this.panel_main.ResumeLayout(false);
            this.panel_cover.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel_slide;
        private Panel panel_qlgsubmenu;
        private Button button_qlg;
        private Button button_thongtindoi;
        private Button button_themcauthu;
        private Button button_quanlidoi;
        private Button button_lichthidau;
        private Panel panel_ltdsubmenu;
        private Button button_xemlichtd;
        private Button button_laplichtd;
        private Panel panel_qdsubmenu;
        private Button button_muagiai;
        private Button button_vongdau;
        private Button button_qdloaicauthu;
        private Button button_qdbanthang;
        private Button button_quydinhct;
        private Button button_quydinh;
        private Panel panel_tbsubmenu;
        private Button button_timkiem;
        private Button button_dsghiban;
        private Button button_bangxh;
        private Button button_trabao;
        private Panel panel_kqsubmenu;
        private Button button_xemkq;
        private Button button_themct;
        private Button button_ghinhan;
        private Button button_kqthidau;
        private Panel panel_main;
        private Panel panel_cover;
        private Panel panel3;
        private Panel panel2;
        private Label label5;
        private Label label1;
        private Panel panel1;
        private Label label6;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private PictureBox pictureBox1;
        private Label label7;
        private Panel panel_logo;
        private Label label4;
        private Label label3;
        private Label label2;
        private Button button_quaylai;
        private Button button_backtrabao;
        private Button button_backkq;
        private Button button_backltd;
        private Button button_backqlg;
    }
}