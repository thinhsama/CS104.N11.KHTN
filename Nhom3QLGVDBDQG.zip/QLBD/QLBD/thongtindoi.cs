﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QLBD
{
    public partial class thongtindoi : Form
    {
        SqlConnection con = new SqlConnection("Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n");

        public thongtindoi()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        
        
        private void thongtindoi_Load(object sender, EventArgs e)
        {
            try
            {
                //SqlConnection con = new SqlConnection("Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n");
                con.Open();
                string qry = "SELECT TENMUA FROM MUAGIAI";
                SqlDataReader dr = new SqlCommand(qry, con).ExecuteReader();
                while(dr.Read())
                {
                    comboBox_chonmuagiai.Items.Add(dr.GetValue(0).ToString());
                }
                dr.Close();
            }
            catch(SqlException x)
            {
                MessageBox.Show(x.Message);
            }
            try
            {
                //SqlConnection con = new SqlConnection("Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n");
                //con.Open();
                string qry = "SELECT TENDOI FROM DOIBONG";
                SqlDataReader dr = new SqlCommand(qry, con).ExecuteReader();
                while (dr.Read())
                {
                    comboBox_chondoi.Items.Add(dr.GetValue(0).ToString());
                }
                dr.Close();
            }
            catch (SqlException x)
            {
                MessageBox.Show(x.Message);
            }
            
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            loaddata();

        }

        private void comboBox_chonmuagiai_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        public void display_comboBox_doibong()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_chondoi.DisplayMember = "TENDOI";
            comboBox_chondoi.DataSource = dt;
        }

        private void comboBox_chondoi_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "SELECT MUAGIAI.TENMUA as 'Mùa', DOIBONG.TENDOI as 'Đội', CAUTHU.TENCT as 'Cầu thủ', CAUTHU.QUOCTICH as 'Quốc tịch', CAUTHU.LOAICAUTHU as 'Loại CT'\r\nFROM CAUTHU JOIN DOIBONG_CAUTHU ON CAUTHU.MACT = DOIBONG_CAUTHU.MACT\r\nJOIN DOIBONG ON DOIBONG.MADOI = DOIBONG_CAUTHU.MADOI\r\nJOIN MUAGIAI ON MUAGIAI.MAMUA = DOIBONG_CAUTHU.MAMUA AND DOIBONG.TENDOI=N'"+ comboBox_chondoi.Text.ToString() + "'";
            SqlCommand sqlcomm = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loaddata()
        {
            //string str1 = comboBox_chonmuagiai.Text, str2 = comboBox_chondoi.Text;
            command = connection.CreateCommand();
            command.CommandText = "SELECT MUAGIAI.TENMUA as 'Mùa', DOIBONG.TENDOI as 'Đội', CAUTHU.TENCT as 'Cầu thủ', CAUTHU.QUOCTICH as 'Quốc tịch', CAUTHU.LOAICAUTHU as 'Loại CT'\r\nFROM CAUTHU JOIN DOIBONG_CAUTHU ON CAUTHU.MACT = DOIBONG_CAUTHU.MACT\r\nJOIN DOIBONG ON DOIBONG.MADOI = DOIBONG_CAUTHU.MADOI\r\nJOIN MUAGIAI ON MUAGIAI.MAMUA = DOIBONG_CAUTHU.MAMUA";
            //command.Parameters.AddWithValue("@str1", str1);
            //command.Parameters.AddWithValue("@str2", str2);
            command.ExecuteNonQuery();
            adapter.SelectCommand = command;
            //table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str1 = comboBox_chonmuagiai.Text;
            string str2 = comboBox_chondoi.Text;
            command = connection.CreateCommand();
            command.CommandText = "SELECT C.MACT, C.TENCT, C.LOAICAUTHU, C.NGAYSINH, C.QUOCTICH FROM DOIBONG D, DOIBONG_CAUTHU DC, DOIBONG_MUAGIAI DM, MUAGIAI M, CAUTHU C WHERE D.MADOI = DC.MADOI AND D.MADOI = DM.MADOI AND DM.MAMUA = M.MAMUA AND DC.MACT = C.MACT AND D.TENDOI = @str1 and M.TENMUA = @str2";
            command.Parameters.AddWithValue("@str1", str1);
            command.Parameters.AddWithValue("@str2", str2);
            command.ExecuteNonQuery();
        }
    }
}
