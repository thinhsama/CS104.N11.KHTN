﻿using Microsoft.Data.SqlClient;
using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class timkiem : Form
    {
        public timkiem()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        DataTable table1 = new DataTable();

        public void display_comboBox1()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox1.DisplayMember = "TENMUA";
            comboBox1.DataSource = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "SELECT MUAGIAI.TENMUA as 'Mùa', DOIBONG.TENDOI as 'Đội', SAN.TENSAN as 'Sân nhà'\r\nFROM SAN JOIN DOIBONG ON SAN.MASAN = DOIBONG.MADOI\r\nJOIN DOIBONG_MUAGIAI ON DOIBONG.MADOI = DOIBONG_MUAGIAI.MADOI\r\nJOIN MUAGIAI ON DOIBONG_MUAGIAI.MAMUA = MUAGIAI.MAMUA WHERE MUAGIAI.TENMUA=" + "N'" + comboBox1.Text.ToString() + "'";
            SqlCommand sqlcomm = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        public void display_comboBox_doibong()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_doibong.DisplayMember = "TENDOI";
            comboBox_doibong.DataSource = dt;
        }

        private void comboBox_doibong_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "SELECT MUAGIAI.TENMUA as 'Mùa', DOIBONG.TENDOI as 'Đội', SAN.TENSAN as 'Sân nhà'\r\nFROM SAN JOIN DOIBONG ON SAN.MASAN = DOIBONG.MADOI\r\nJOIN DOIBONG_MUAGIAI ON DOIBONG.MADOI = DOIBONG_MUAGIAI.MADOI\r\nJOIN MUAGIAI ON DOIBONG_MUAGIAI.MAMUA = MUAGIAI.MAMUA WHERE DOIBONG.TENDOI=" + "N'" + comboBox_doibong.Text.ToString() + "' AND MUAGIAI.TENMUA = N'" + comboBox1.Text.ToString() + "'";
            SqlCommand sqlcomm = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        public void display_comboBox_cauthu()
        {
            string query = "SELECT TENCT FROM CAUTHU";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_cauthu.DisplayMember = "TENCT";
            comboBox_cauthu.DataSource = dt;
        }

        private void comboBox_cauthu_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "SELECT TENMUA, TENDOI,TENCT, NGAYSINH, QUOCTICH, LOAICAUTHU  FROM CAUTHU C, DOIBONG D, DOIBONG_CAUTHU DC, MUAGIAI M WHERE D.MADOI = DC.MADOI AND DC.MACT = C.MACT AND DC.MAMUA = M.MAMUA AND TENCT = N'Nguyễn Tuấn Anh' AND TENMUA = 'V-League 2015'";
            SqlCommand sqlcomm = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void load_data_dataGridview2()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM CAUTHU";
            adapter.SelectCommand = command;
            table1.Clear();
            adapter.Fill(table1);
            dataGridView2.DataSource = table1;
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void load_data_dataGridView1()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT MUAGIAI.TENMUA as 'Mùa', DOIBONG.TENDOI as 'Đội', SAN.TENSAN as 'Sân nhà'\r\nFROM SAN JOIN DOIBONG ON SAN.MASAN = DOIBONG.MADOI\r\nJOIN DOIBONG_MUAGIAI ON DOIBONG.MADOI = DOIBONG_MUAGIAI.MADOI\r\nJOIN MUAGIAI ON DOIBONG_MUAGIAI.MAMUA = MUAGIAI.MAMUA";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void timkiem_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            display_comboBox_doibong();
            display_comboBox1();
            display_comboBox_cauthu();
            load_data_dataGridView1();
            load_data_dataGridview2();
        }
    }
}
