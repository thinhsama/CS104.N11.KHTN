﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class muagiai : Form
    {
        public muagiai()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void load_data()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT * FROM MUAGIAI";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void muagiai_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            load_data();
        }
    }
}
