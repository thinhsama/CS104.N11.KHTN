﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class qdbanthang : Form
    {
        public qdbanthang()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();


        

        public void load_data()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT MAQD as 'Mã QĐ', TDGHIBANTOIDA as 'Thời điểm ghi bàn tối đa', THANG as 'Thắng', HOA as 'Hòa', THUA as 'Thua' FROM QUYDINHBANTHANG";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //int i = dataGridView1.CurrentRow.Index;
            //textBox2.Text = dataGridView1.Rows[i].Cells[0].Value.ToString();
            //textBox1.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            //textBox_succhua.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            //textBox_diachi.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
        }

        /*private void qdbanthang_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            load_data();
        }*/

        private void textBox_tuoitt_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void qdbanthang_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            load_data();
        }
    }
}
