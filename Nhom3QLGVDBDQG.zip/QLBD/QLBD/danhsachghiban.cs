﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class danhsachghiban : Form
    {
        public danhsachghiban()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        public void load_data()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT MAGB as 'Mã GB', MACT as 'Mã CT', TENCT as 'Tên CT', MADOI as 'Mã đội', TENDOI as 'Tên đội', LOAICT as 'Loại CT', SOBANTHANG as 'Số bàn' FROM DANHSACHGHIBAN";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
            //dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void danhsachghiban_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            load_data();
            display_combobox_doibong();
            display_comboBox1();
        }

        public void display_combobox_doibong()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_doibong.DisplayMember = "TENDOI";
            comboBox_doibong.DataSource = dt;
        }

        private void comboBox_doibong_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "SELECT MAGB as 'Mã GB', MACT as 'Mã CT', TENCT as 'Tên CT', MADOI as 'Mã đội', TENDOI as 'Tên đội', LOAICT as 'Loại CT', SOBANTHANG as 'Số bàn' FROM DANHSACHGHIBAN WHERE TENDOI=" + "N'" + comboBox_doibong.Text.ToString() + "'";
            SqlCommand sqlcomm = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            dataGridView1.DataSource = dt;
            //connection.Close();

            /*command = connection.CreateCommand();
            command.CommandText = "SELECT MAGB as 'Mã GB', MACT as 'Mã CT', TENCT as 'Tên CT', MADOI as 'Mã đội', TENDOI as 'Tên đội', LOAICT as 'Loại CT', SOBANTHANG as 'Số bàn' FROM DANHSACHGHIBAN WHERE TENDOI='" + comboBox_doibong.SelectedItem.ToString() + "'";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;*/
        }

        public void display_comboBox1()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox1.DisplayMember = "TENMUA";
            comboBox1.DataSource = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
