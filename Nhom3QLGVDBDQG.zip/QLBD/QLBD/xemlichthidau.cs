﻿using Microsoft.Data.SqlClient;
using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TheArtOfDevHtmlRenderer.Adapters;

namespace QLBD
{
    public partial class xemlichthidau : Form
    {
        public xemlichthidau()
        {
            InitializeComponent();
        }

        //public string tmp="";

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        public void load_data()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT MATD as 'Mã TD', NGAYGIO as 'Ngày giờ', TENDOI1 as 'Tên đội 1', TENDOI2 as 'Tên đội 2', TENVONG as 'Vòng', TENMUA as 'Mùa', TENSAN as 'Sân' FROM TRANDAU";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void xemlichthidau_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            load_data();
            display_comboBox1();
            display_comboBox_chonmuagiai();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void display_comboBox1()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox1.DisplayMember = "TENDOI";
            comboBox1.DataSource = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            /*string query = "SELECT MATD as 'Mã TD', NGAYGIO as 'Ngày giờ', TENDOI1 as 'Tên đội 1', TENDOI2 as 'Tên đội 2', TENVONG as 'Vòng', TENMUA as 'Mùa', TENSAN as 'Sân' FROM TRANDAU WHERE TENDOI=" + "N'" + comboBox1.Text.ToString() + "' AND TENMUA = " + "N'" + tmp + "'";
            SqlCommand sqlcomm = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            dataGridView1.DataSource = dt;*/
        }

        public void display_comboBox_chonmuagiai()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_chonmuagiai.DisplayMember = "TENMUA";
            comboBox_chonmuagiai.DataSource = dt;
        }

        //public string tmp;

        private void comboBox_chonmuagiai_SelectedIndexChanged(object sender, EventArgs e)
        {
            string query = "SELECT MATD as 'Mã TD', NGAYGIO as 'Ngày giờ', TENDOI1 as 'Tên đội 1', TENDOI2 as 'Tên đội 2', TENVONG as 'Vòng', TENMUA as 'Mùa', TENSAN as 'Sân' FROM TRANDAU WHERE TENMUA=" + "N'" + comboBox_chonmuagiai.Text.ToString() + "'";
            //tmp = comboBox_chonmuagiai.Text;
            SqlCommand sqlcomm = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlcomm);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            dataGridView1.DataSource = dt;
        }
    }
}
