﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class bangxephang : Form
    {
        public bangxephang()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        public void load_data()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT HANG as 'Hạng', MADOI as 'Mã đội', TENDOI as 'Tên đội', THANG as 'Thắng', HOA as 'Hòa', THUA as 'Thua', HIEUSO as 'Hiệu số' FROM BANGXEPHANG";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bangxephang_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            load_data();

            display_Combobox1();


            //comboBox1.DisplayMember
        }

        public void display_Combobox1()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox1.DisplayMember = "TENMUA";
            comboBox1.DataSource = dt;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
