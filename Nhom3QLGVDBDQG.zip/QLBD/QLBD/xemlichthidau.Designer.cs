﻿namespace QLBD
{
    partial class xemlichthidau
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_thongtindoi = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.comboBox_chonmuagiai = new System.Windows.Forms.ComboBox();
            this.label_chonmuagiai = new System.Windows.Forms.Label();
            this.label_timdoi = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_thongtindoi);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 14;
            // 
            // label_thongtindoi
            // 
            this.label_thongtindoi.AutoSize = true;
            this.label_thongtindoi.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_thongtindoi.ForeColor = System.Drawing.Color.White;
            this.label_thongtindoi.Location = new System.Drawing.Point(272, 9);
            this.label_thongtindoi.Name = "label_thongtindoi";
            this.label_thongtindoi.Size = new System.Drawing.Size(309, 37);
            this.label_thongtindoi.TabIndex = 0;
            this.label_thongtindoi.Text = "Thông Tin Lịch Thi Đấu";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(14, 71);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 265);
            this.dataGridView1.TabIndex = 15;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // comboBox_chonmuagiai
            // 
            this.comboBox_chonmuagiai.FormattingEnabled = true;
            this.comboBox_chonmuagiai.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox_chonmuagiai.Location = new System.Drawing.Point(644, 393);
            this.comboBox_chonmuagiai.Name = "comboBox_chonmuagiai";
            this.comboBox_chonmuagiai.Size = new System.Drawing.Size(200, 28);
            this.comboBox_chonmuagiai.TabIndex = 34;
            this.comboBox_chonmuagiai.SelectedIndexChanged += new System.EventHandler(this.comboBox_chonmuagiai_SelectedIndexChanged);
            // 
            // label_chonmuagiai
            // 
            this.label_chonmuagiai.AutoSize = true;
            this.label_chonmuagiai.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_chonmuagiai.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_chonmuagiai.Location = new System.Drawing.Point(488, 389);
            this.label_chonmuagiai.Name = "label_chonmuagiai";
            this.label_chonmuagiai.Size = new System.Drawing.Size(108, 28);
            this.label_chonmuagiai.TabIndex = 33;
            this.label_chonmuagiai.Text = "Mùa Giải :";
            // 
            // label_timdoi
            // 
            this.label_timdoi.AutoSize = true;
            this.label_timdoi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_timdoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_timdoi.Location = new System.Drawing.Point(14, 385);
            this.label_timdoi.Name = "label_timdoi";
            this.label_timdoi.Size = new System.Drawing.Size(98, 28);
            this.label_timdoi.TabIndex = 35;
            this.label_timdoi.Text = "Tìm Đội :";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox1.Location = new System.Drawing.Point(154, 389);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(200, 28);
            this.comboBox1.TabIndex = 37;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.button1.Location = new System.Drawing.Point(719, 486);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(94, 43);
            this.button1.TabIndex = 38;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(0, 486);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 39;
            this.pictureBox2.TabStop = false;
            // 
            // xemlichthidau
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label_timdoi);
            this.Controls.Add(this.comboBox_chonmuagiai);
            this.Controls.Add(this.label_chonmuagiai);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel_themct);
            this.MinimumSize = new System.Drawing.Size(874, 603);
            this.Name = "xemlichthidau";
            this.Text = "Xem Lịch Thi Đấu";
            this.Load += new System.EventHandler(this.xemlichthidau_Load);
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel_themct;
        private Label label_thongtindoi;
        private DataGridView dataGridView1;
        private ComboBox comboBox_chonmuagiai;
        private Label label_chonmuagiai;
        private Label label_timdoi;
        private ComboBox comboBox1;
        private Button button1;
        private PictureBox pictureBox2;
    }
}