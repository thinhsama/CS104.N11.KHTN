﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QLBD
{
    public partial class vongdau : Form
    {
        public vongdau()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        private void vongdau_Load(object sender, EventArgs e)
        {
            connection = new SqlConnection(str);
            connection.Open();
            load_data();
            display_comboBox_chonmuagiai();
        }

        public void load_data()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT MAVONG, TENVONG, TENMUA FROM VONGDAU V, MUAGIAI M WHERE V.MAMUA = M.MAMUA";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox_tenvd_TextChanged(object sender, EventArgs e)
        {

        }

        public void display_comboBox_chonmuagiai()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_chonmuagiai.DisplayMember = "TENMUA";
            comboBox_chonmuagiai.DataSource = dt;
        }

        private void comboBox_chonmuagiai_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        static int i = 20, j = 20, k = 20;
        private void button_them_Click(object sender, EventArgs e)
        {
            /*command = connection.CreateCommand();
            command.CommandText = "INSERT INTO VONGDAU VALUES(@MAVONG,@TENVONG, @MAMUA)";
            command.Parameters.AddWithValue("@MAVONG", i);
            command.Parameters.AddWithValue("@TENVONG", j);
            command.Parameters.AddWithValue("@MAMUA", k);*/
            
        }
    }
}
