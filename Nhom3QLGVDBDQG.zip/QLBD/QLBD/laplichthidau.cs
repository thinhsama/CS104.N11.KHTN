﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QLBD
{
    public partial class laplichthidau : Form
    {
        public laplichthidau()
        {
            InitializeComponent();
        }

        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();
        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT MATD as 'Mã TD', NGAYGIO as 'Ngày giờ', TENDOI1 as 'Tên đội 1', TENDOI2 as 'Tên đội 2', TENVONG as 'Vòng', TENMUA as 'Mùa', TENSAN as 'Sân' FROM TRANDAU";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }

        public void display_comboBox_chonmuagiai()
        {
            string query = "SELECT TENMUA FROM MUAGIAI";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_chonmuagiai.DisplayMember = "TENMUA";
            comboBox_chonmuagiai.DataSource = dt;
        }
        public void display_comboBox_doi1()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_doi1.DisplayMember = "TENDOI";
            comboBox_doi1.DataSource = dt;
        }
        public void display_comboBox_doi2()
        {
            string query = "SELECT TENDOI FROM DOIBONG";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox_doi2.DisplayMember = "TENDOI";
            comboBox_doi2.DataSource = dt;
        }
        public void display_comboBox2()
        {
            string query = "SELECT TENSAN FROM SAN";
            SqlCommand sqlc = new SqlCommand(query, connection);
            //connection.Open();
            SqlDataAdapter sdr = new SqlDataAdapter(sqlc);
            DataTable dt = new DataTable();
            sdr.Fill(dt);
            comboBox2.DisplayMember = "TENSAN";
            comboBox2.DataSource = dt;
        }
        private void comboBox_chonmuagiai_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_vongdau_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_doi1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox_doi2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void laplichthidau_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            loaddata();
            display_comboBox_chonmuagiai();
            display_comboBox_doi1();
            display_comboBox_doi2();
            display_comboBox2();
        }
        static int i = 1;
        private void button_them_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "INSERT INTO TRANDAU VALUES(@MATD, @NGAYGIO, @TENDOI1, @TENDOI2,@TENVONG, @TENMUA, @TENSAN)";
            command.Parameters.AddWithValue("@MATD", i);
            command.Parameters.AddWithValue("@TENDOI1", comboBox_doi1.Text);
            command.Parameters.AddWithValue("@TENDOI2", comboBox_doi2.Text);
            command.Parameters.AddWithValue("@NGAYGIO", dateTimePicker1.Text);
            command.Parameters.AddWithValue("@TENSAN", comboBox2.Text);
            command.Parameters.AddWithValue("@TENVONG", comboBox_vongdau.Text);
            command.Parameters.AddWithValue("@TENMUA", comboBox_chonmuagiai.Text);
            command.ExecuteNonQuery();
            i++;
            loaddata();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
