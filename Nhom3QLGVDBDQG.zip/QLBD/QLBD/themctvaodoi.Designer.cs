﻿namespace QLBD
{
    partial class themctvaodoi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_themct = new System.Windows.Forms.Panel();
            this.label_themct = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.textBox_loaict = new System.Windows.Forms.TextBox();
            this.textBox_hoten = new System.Windows.Forms.TextBox();
            this.label_hoten = new System.Windows.Forms.Label();
            this.textBox_quoctich = new System.Windows.Forms.TextBox();
            this.label_quoctich = new System.Windows.Forms.Label();
            this.textBox_ngaysinh = new System.Windows.Forms.TextBox();
            this.label_ngaysinh = new System.Windows.Forms.Label();
            this.textBox_ghichu = new System.Windows.Forms.TextBox();
            this.label_ghichu = new System.Windows.Forms.Label();
            this.button_them = new System.Windows.Forms.Button();
            this.button_sua = new System.Windows.Forms.Button();
            this.button_xoa = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label_chondoi = new System.Windows.Forms.Label();
            this.comboBox_chondoi = new System.Windows.Forms.ComboBox();
            this.panel_themct.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel_themct
            // 
            this.panel_themct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.panel_themct.Controls.Add(this.label_themct);
            this.panel_themct.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_themct.Location = new System.Drawing.Point(0, 0);
            this.panel_themct.Name = "panel_themct";
            this.panel_themct.Size = new System.Drawing.Size(856, 61);
            this.panel_themct.TabIndex = 12;
            // 
            // label_themct
            // 
            this.label_themct.AutoSize = true;
            this.label_themct.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_themct.ForeColor = System.Drawing.Color.White;
            this.label_themct.Location = new System.Drawing.Point(259, 9);
            this.label_themct.Name = "label_themct";
            this.label_themct.Size = new System.Drawing.Size(306, 37);
            this.label_themct.TabIndex = 0;
            this.label_themct.Text = "Thêm Cầu Thủ Vào Đội";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 29;
            this.dataGridView1.Size = new System.Drawing.Size(832, 205);
            this.dataGridView1.TabIndex = 13;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label1.Location = new System.Drawing.Point(29, 390);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 28);
            this.label1.TabIndex = 15;
            this.label1.Text = "Loại CT :";
            // 
            // textBox_loaict
            // 
            this.textBox_loaict.Location = new System.Drawing.Point(145, 394);
            this.textBox_loaict.Name = "textBox_loaict";
            this.textBox_loaict.Size = new System.Drawing.Size(200, 27);
            this.textBox_loaict.TabIndex = 17;
            // 
            // textBox_hoten
            // 
            this.textBox_hoten.Location = new System.Drawing.Point(569, 318);
            this.textBox_hoten.Name = "textBox_hoten";
            this.textBox_hoten.Size = new System.Drawing.Size(200, 27);
            this.textBox_hoten.TabIndex = 19;
            // 
            // label_hoten
            // 
            this.label_hoten.AutoSize = true;
            this.label_hoten.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_hoten.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_hoten.Location = new System.Drawing.Point(432, 314);
            this.label_hoten.Name = "label_hoten";
            this.label_hoten.Size = new System.Drawing.Size(113, 28);
            this.label_hoten.TabIndex = 18;
            this.label_hoten.Text = "Họ Tên CT:";
            // 
            // textBox_quoctich
            // 
            this.textBox_quoctich.Location = new System.Drawing.Point(569, 394);
            this.textBox_quoctich.Name = "textBox_quoctich";
            this.textBox_quoctich.Size = new System.Drawing.Size(200, 27);
            this.textBox_quoctich.TabIndex = 21;
            // 
            // label_quoctich
            // 
            this.label_quoctich.AutoSize = true;
            this.label_quoctich.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_quoctich.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_quoctich.Location = new System.Drawing.Point(427, 390);
            this.label_quoctich.Name = "label_quoctich";
            this.label_quoctich.Size = new System.Drawing.Size(118, 28);
            this.label_quoctich.TabIndex = 20;
            this.label_quoctich.Text = "Quốc Tịch :";
            // 
            // textBox_ngaysinh
            // 
            this.textBox_ngaysinh.Location = new System.Drawing.Point(145, 463);
            this.textBox_ngaysinh.Name = "textBox_ngaysinh";
            this.textBox_ngaysinh.Size = new System.Drawing.Size(200, 27);
            this.textBox_ngaysinh.TabIndex = 23;
            // 
            // label_ngaysinh
            // 
            this.label_ngaysinh.AutoSize = true;
            this.label_ngaysinh.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_ngaysinh.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_ngaysinh.Location = new System.Drawing.Point(1, 459);
            this.label_ngaysinh.Name = "label_ngaysinh";
            this.label_ngaysinh.Size = new System.Drawing.Size(120, 28);
            this.label_ngaysinh.TabIndex = 22;
            this.label_ngaysinh.Text = "Ngày Sinh :";
            // 
            // textBox_ghichu
            // 
            this.textBox_ghichu.Location = new System.Drawing.Point(569, 463);
            this.textBox_ghichu.Name = "textBox_ghichu";
            this.textBox_ghichu.Size = new System.Drawing.Size(200, 27);
            this.textBox_ghichu.TabIndex = 25;
            // 
            // label_ghichu
            // 
            this.label_ghichu.AutoSize = true;
            this.label_ghichu.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_ghichu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_ghichu.Location = new System.Drawing.Point(448, 463);
            this.label_ghichu.Name = "label_ghichu";
            this.label_ghichu.Size = new System.Drawing.Size(97, 28);
            this.label_ghichu.TabIndex = 24;
            this.label_ghichu.Text = "Ghi Chú :";
            // 
            // button_them
            // 
            this.button_them.BackColor = System.Drawing.Color.Green;
            this.button_them.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_them.ForeColor = System.Drawing.Color.White;
            this.button_them.Location = new System.Drawing.Point(361, 507);
            this.button_them.Name = "button_them";
            this.button_them.Size = new System.Drawing.Size(94, 37);
            this.button_them.TabIndex = 26;
            this.button_them.Text = "Thêm";
            this.button_them.UseVisualStyleBackColor = false;
            // 
            // button_sua
            // 
            this.button_sua.BackColor = System.Drawing.Color.Yellow;
            this.button_sua.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_sua.ForeColor = System.Drawing.Color.White;
            this.button_sua.Location = new System.Drawing.Point(523, 507);
            this.button_sua.Name = "button_sua";
            this.button_sua.Size = new System.Drawing.Size(94, 37);
            this.button_sua.TabIndex = 27;
            this.button_sua.Text = "Sửa";
            this.button_sua.UseVisualStyleBackColor = false;
            // 
            // button_xoa
            // 
            this.button_xoa.BackColor = System.Drawing.Color.Red;
            this.button_xoa.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button_xoa.ForeColor = System.Drawing.Color.White;
            this.button_xoa.Location = new System.Drawing.Point(675, 507);
            this.button_xoa.Name = "button_xoa";
            this.button_xoa.Size = new System.Drawing.Size(94, 37);
            this.button_xoa.TabIndex = 28;
            this.button_xoa.Text = "Xóa";
            this.button_xoa.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::QLBD.Properties.Resources.v_league;
            this.pictureBox2.Location = new System.Drawing.Point(0, 507);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(125, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 29;
            this.pictureBox2.TabStop = false;
            // 
            // label_chondoi
            // 
            this.label_chondoi.AutoSize = true;
            this.label_chondoi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label_chondoi.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(71)))), ((int)(((byte)(160)))));
            this.label_chondoi.Location = new System.Drawing.Point(11, 311);
            this.label_chondoi.Name = "label_chondoi";
            this.label_chondoi.Size = new System.Drawing.Size(110, 28);
            this.label_chondoi.TabIndex = 30;
            this.label_chondoi.Text = "Chọn Đội :";
            // 
            // comboBox_chondoi
            // 
            this.comboBox_chondoi.FormattingEnabled = true;
            this.comboBox_chondoi.Items.AddRange(new object[] {
            "2021-2022",
            "2022-2023",
            "2023-2024",
            "2024-2025",
            "2025-2026"});
            this.comboBox_chondoi.Location = new System.Drawing.Point(145, 315);
            this.comboBox_chondoi.Name = "comboBox_chondoi";
            this.comboBox_chondoi.Size = new System.Drawing.Size(200, 28);
            this.comboBox_chondoi.TabIndex = 31;
            this.comboBox_chondoi.SelectedIndexChanged += new System.EventHandler(this.comboBox_chondoi_SelectedIndexChanged);
            // 
            // themctvaodoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(856, 556);
            this.Controls.Add(this.comboBox_chondoi);
            this.Controls.Add(this.label_chondoi);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.button_xoa);
            this.Controls.Add(this.button_sua);
            this.Controls.Add(this.button_them);
            this.Controls.Add(this.textBox_ghichu);
            this.Controls.Add(this.label_ghichu);
            this.Controls.Add(this.textBox_ngaysinh);
            this.Controls.Add(this.label_ngaysinh);
            this.Controls.Add(this.textBox_quoctich);
            this.Controls.Add(this.label_quoctich);
            this.Controls.Add(this.textBox_hoten);
            this.Controls.Add(this.label_hoten);
            this.Controls.Add(this.textBox_loaict);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel_themct);
            this.MinimumSize = new System.Drawing.Size(874, 603);
            this.Name = "themctvaodoi";
            this.Text = "Thêm Cầu Thủ Vào Đội";
            this.Load += new System.EventHandler(this.themctvaodoi_Load);
            this.panel_themct.ResumeLayout(false);
            this.panel_themct.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel_themct;
        private Label label_themct;
        private DataGridView dataGridView1;
        private Label label1;
        private TextBox textBox_loaict;
        private TextBox textBox_hoten;
        private Label label_hoten;
        private TextBox textBox_quoctich;
        private Label label_quoctich;
        private TextBox textBox_ngaysinh;
        private Label label_ngaysinh;
        private TextBox textBox_ghichu;
        private Label label_ghichu;
        private Button button_them;
        private Button button_sua;
        private Button button_xoa;
        private PictureBox pictureBox2;
        private Label label_chondoi;
        private ComboBox comboBox_chondoi;
    }
}