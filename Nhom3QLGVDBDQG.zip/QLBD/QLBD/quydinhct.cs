﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLBD
{
    public partial class quydinhct : Form
    {
        public quydinhct()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int i = dataGridView1.CurrentRow.Index;
            textBox_tuoitt.Text = dataGridView1.Rows[i].Cells[1].Value.ToString();
            textBox2.Text = dataGridView1.Rows[i].Cells[2].Value.ToString();
            textBox_socttt.Text = dataGridView1.Rows[i].Cells[3].Value.ToString();
            textBox3.Text = dataGridView1.Rows[i].Cells[4].Value.ToString();
            textBox1.Text = dataGridView1.Rows[i].Cells[5].Value.ToString();
        }
        SqlConnection connection;
        SqlCommand command;
        string str = "Data Source=LAPTOP-KTHP1HSK;Initial Catalog=QLBD;Integrated Security=True;TrustServerCertificate=True\r\n";
        SqlDataAdapter adapter = new SqlDataAdapter();
        DataTable table = new DataTable();

        void loaddata()
        {
            command = connection.CreateCommand();
            command.CommandText = "SELECT MAQD as 'Mã QĐ', TUOITOITHIEU as 'Tuổi tối thiểu', TUOITOIDA as 'Tuổi tối đa', SOCTTOITHIEU as 'Số CT tối thiểu', SOCTTOIDA as 'Số CT tối đa', SOCTNUOCNGOAITOIDA as 'Số CT nước ngoài tối đa' FROM QUYDINHCAUTHU";
            adapter.SelectCommand = command;
            table.Clear();
            adapter.Fill(table);
            dataGridView1.DataSource = table;
        }
        static int i = 30, j = 0, k = 0;

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_xoa_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "Delete FROM QUYDINHCAUTHU WHERE TUOITOITHIEU = @TUOITOITHIEU";
            command.Parameters.AddWithValue("@TUOITOITHIEU", textBox_tuoitt.Text);
            command.ExecuteNonQuery();
            loaddata();
        }

        private void textBox_tuoitt_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox_socttt_TextChanged(object sender, EventArgs e)
        {

        }

        private void button_them_Click(object sender, EventArgs e)
        {
            command = connection.CreateCommand();
            command.CommandText = "INSERT INTO QUYDINHCAUTHU VALUES(@MAQD, @TUOITOITHIEU, @TUOITOIDA, @SOCTTOITHIEU, @SOCTTOIDA, @SOCTNUOCNGOAITOIDA)";
            command.Parameters.AddWithValue("@MAQD", i);
            command.Parameters.AddWithValue("@TUOITOITHIEU", textBox_tuoitt.Text);
            command.Parameters.AddWithValue("@TUOITOIDA", textBox2.Text);
            command.Parameters.AddWithValue("@SOCTTOITHIEU", textBox_socttt.Text);
            command.Parameters.AddWithValue("@SOCTTOIDA", textBox3.Text);
            command.Parameters.AddWithValue("@SOCTNUOCNGOAITOIDA", textBox1.Text);


            i++;
            command.ExecuteNonQuery();
            loaddata();
        }

        private void quydinhct_Load(object sender, EventArgs e)
        {
            connection = new Microsoft.Data.SqlClient.SqlConnection(str);
            connection.Open();
            loaddata();
        }
    }
}
